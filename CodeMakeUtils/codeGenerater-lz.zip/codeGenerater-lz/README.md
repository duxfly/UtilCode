# codeGenerater
a  ssh2/springmvc  codeGenerater written by bruce .(me hahaha. very haoyong 2015-5-13 11:04:56)

##添加对Mac OS X ||linux 系统的支持；添加mybatis部分template（2015-12-21 16:39:09 ）

###运行test.java,首先初始化db连接，然后指定表来生成或者生成当前连接库的所有表对应的模板实体。
###db.java,来配置数据库的连接.
###Tabel类指定了包名。
###rs目录下面是velocity模板，根据项目的相关路径和命名来自行扩展编写。
##Tips by Bruce 2016-06-20
