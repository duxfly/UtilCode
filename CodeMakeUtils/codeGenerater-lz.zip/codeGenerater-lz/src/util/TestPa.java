package util;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class TestPa {
	public static void main(String[] args) {
//		Document document = null;
//		try {
//			document = Jsoup.connect("http://www.lagou.com/jobs/list_Java?px=default&city=%E5%8C%97%E4%BA%AC&district=%E6%B5%B7%E6%B7%80%E5%8C%BA#filterBox").get();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		String title = document.html();
//		System.out.println(title);
		Integer a[]={82,21,39,49,32,4,24,76,485};
		Integer b[]={21,54,59,15,27,39,49,32,4,24,76,485,615,260,1235};
		//Set<Integer> aa = new HashSet(Arrays.asList(a));
		Set<Integer> bb = new HashSet(Arrays.asList(b));
		//Set<Integer> cc = new HashSet(Arrays.asList(a));
		for (int aaa : a) {
			if(bb.contains(aaa)){
				//System.out.println(aaa);
			}
		}
		
//		for(int i=0;i<a.length;i++){
//			for(int j=0;j<b.length;j++){
//				if(a[i]==b[j]){
//					//System.out.print(a[i]);
//				}
//			}
//		}
		
		
		Integer i = 3;
		Integer j = 3;
		if(i==j){
			System.out.println("---");
			System.out.println("i==j");
		}else{
			System.out.println("i!=j");
		}
		Integer ii = 300;
		Integer jj = 300;
		if(ii==jj){
			System.out.println("---");
			System.out.println("ii==jj");
		}else{
			System.out.println("ii!=jj");
		}
			
		
	}
}
