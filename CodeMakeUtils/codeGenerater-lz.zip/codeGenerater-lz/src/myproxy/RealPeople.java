package myproxy;

/**
 * 真正的人诞生[实现People接口]
 * @author flower
 */
public class RealPeople implements People{

	@Override
	public void hello(String name) {
		System.out.println("我的名字叫:"+name);
	}

	@Override
	public void dance() {
		System.out.println(" 我给大家跳支舞!!");
	}
	
	public void say(){
		System.out.println(" 大家好，我挑的怎么样");
	}

}
