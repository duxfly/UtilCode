package myproxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

/***
 * 创建代理类
 * @author flower
 */
public class DynamicProxy implements InvocationHandler{
	private Object obj;
	
	public DynamicProxy(Object realyProxy) {
		this.obj =  realyProxy;
	}

	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		System.out.println("进入了动态代理!");  //调用真正的方法之前可以做的事情
	    System.out.println("proxy:"+proxy.getClass().getName()); 
		System.out.println("Method:" + method);
		//注意这里使用的是obj是构造参数传过来的realyProxy
		method.invoke(obj, args);
		System.out.println("结束动态代理!"); //调用真正的方法之后可以做的事情
		return null;
	}

}
