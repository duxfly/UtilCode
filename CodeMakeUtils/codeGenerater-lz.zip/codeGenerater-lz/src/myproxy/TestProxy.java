package myproxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;

/***
 * 运行动态代理[造人]
 * @author flower
 */
public class TestProxy {
	public static void main(String[] args) {
		//创建句柄 参数传realPeople类
		InvocationHandler handler = new DynamicProxy(new RealPeople());
		People p =(People) Proxy.newProxyInstance(People.class.getClassLoader(), new Class[]{People.class}, handler);
		//newProxyInstance(1,2,3) 第二个参数也可以这么写 不过要写成realpeople.class.getInterFaces()因为realpeople也可能接两个接口[比如说狼人]这样就能获取到所有的借口方法列表
		//People p =(People) Proxy.newProxyInstance(handler.getClass().getClassLoader(), RealPeople.class.getInterfaces(), handler);
		
		System.out.println(p.getClass().getName());
		p.hello("小明");
		p.dance();
	}
}
