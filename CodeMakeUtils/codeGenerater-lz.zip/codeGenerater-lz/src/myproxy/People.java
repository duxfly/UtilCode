package myproxy;

/**
 * 定义人类的接口
 * @author flower
 */
public interface People {
	public void hello(String name);
	
	public void dance();

}
