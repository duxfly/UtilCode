package com.jx.blackface.messagecenter.sms.entity;

public class SmsEntity {
	private String smsId;
	private String text;
	private String respCode;
	private String createDate;
	private String othMsg;
	private short channel;


	public short getChannel() {
		return channel;
	}

	public void setChannel(short channel) {
		this.channel = channel;
	}

	public String getSmsId() {
		return smsId;
	}

	public void setSmsId(String smsId) {
		this.smsId = smsId;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getRespCode() {
		return respCode;
	}

	public void setRespCode(String respCode) {
		this.respCode = respCode;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getOthMsg() {
		return othMsg;
	}

	public void setOthMsg(String othMsg) {
		this.othMsg = othMsg;
	}



	public String toString() {
		return "smsId:" + this.smsId + "    respCode:" + this.respCode + "    text:" + this.text + "    createDate:"
				+ this.createDate + "    othMsg:" + this.othMsg + "    channel:" + this.channel;
	}

}
