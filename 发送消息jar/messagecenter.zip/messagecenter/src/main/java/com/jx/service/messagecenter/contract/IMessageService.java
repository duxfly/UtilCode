package com.jx.service.messagecenter.contract;

import com.jx.spat.gaea.server.contract.annotation.OperationContract;
import com.jx.spat.gaea.server.contract.annotation.ServiceContract;

@ServiceContract
public interface IMessageService {
	@OperationContract
	public String sendMessage(String phonenumber,String content)throws Exception;
	@OperationContract
	public String sendActionMessage(String phonenumber,int msgcode)throws Exception;
	
	
}
