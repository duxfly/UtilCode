package com.jx.service.messagecenter.contract;

import java.util.List;

import com.jx.service.messagecenter.entity.AuthMsgEntity;
import com.jx.service.messagecenter.entity.MobileSmsResult;
import com.jx.service.messagecenter.entity.MobileSmsResultExt;
import com.jx.spat.gaea.server.contract.annotation.OperationContract;
import com.jx.spat.gaea.server.contract.annotation.ServiceContract;

@ServiceContract
public interface IMoblieSmsService {
	@OperationContract
	public MobileSmsResult sendMsg(String phone,String content) throws Exception;
	@OperationContract	
	public MobileSmsResult sendMsg(String phone, String temp,String []msgContent) throws Exception ;
	@OperationContract		
	public MobileSmsResult sendBusinessMsg(String phone, String text) throws Exception ;
	@OperationContract
	public MobileSmsResultExt sendVerifyCode(String phone) throws Exception;
	@OperationContract
	public MobileSmsResultExt sendVerifyCode(String phone,short channel) throws Exception;
	@OperationContract
	public Boolean checkVerifyCode(String phone, String code) throws Exception;
	@OperationContract
	public long addMsgEntity(AuthMsgEntity e)throws Exception;
	@OperationContract
	public int getCount(String condition)throws Exception;
	@OperationContract
	public AuthMsgEntity getMsgEntityById(long Followupid)throws Exception; 
	@OperationContract
	public List<AuthMsgEntity> getMsgEntity(String condition,
			int pageindex,int pagesize,String orderby)throws Exception;
	@OperationContract
	public void updateMsgEntity(AuthMsgEntity e)throws Exception;
}