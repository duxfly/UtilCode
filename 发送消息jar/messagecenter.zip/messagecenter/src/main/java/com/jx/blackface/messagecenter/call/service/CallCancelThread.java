package com.jx.blackface.messagecenter.call.service;

import com.jx.blackface.messagecenter.call.entity.CallbackEntity;
import com.jx.service.messagecenter.components.MoblieSmsService;
import com.jx.service.messagecenter.contract.IMoblieSmsService;

public class CallCancelThread implements Runnable {

	public static IMoblieSmsService  imss = new MoblieSmsService();

	
	
	private Class<?> clz;
	private long msgid;
	public CallCancelThread(Class<?> clz,long msgid) {
		this.clz = clz;
		this.msgid = msgid;
	}

	public long getMsgid() {
		return msgid;
	}

	public void setMsgid(long msgid) {
		this.msgid = msgid;
	}

	
	@Override
	public void run() {
		Object msgserv  = null;
		try {
			 msgserv = Class.forName(clz.getName()).newInstance();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(msgserv instanceof BaseCallService){
			BaseCallService bme = (BaseCallService)msgserv;
			CallbackEntity  ce = bme.callcancel( this.msgid);
			
		}

	}

}
