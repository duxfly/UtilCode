package com.jx.blackface.messagecenter.sms.service;



import java.util.Date;

import com.alibaba.fastjson.JSONObject;
import com.jx.blackface.messagecenter.sms.entity.SmsEntity;
import com.jx.service.messagecenter.components.MoblieSmsService;
import com.jx.service.messagecenter.contract.IMoblieSmsService;
import com.jx.service.messagecenter.entity.AuthMsgEntity;


public abstract class BaseMessageService{

	// 显号号码
	public static final String DISPNUMBER010 = "01084463639";
	
	public static IMoblieSmsService  imss = new MoblieSmsService();

//	public static long initAuthMsg(String phone,String code) throws Exception{
//		AuthMsgEntity ame = new AuthMsgEntity();
//		ame.setPhonenumber(phone);
//		ame.setMsgtext(code);
//		ame.setSendstate((short)-1);
//		ame.setMsgtype((short)1);
//		ame.setSendtimestamp(new Date());
//		long re = imss.addMsgEntity(ame);
//		return re;
//	}
	public abstract SmsEntity sendMessage(String template, String phone, String[] text, long sel);
	public abstract SmsEntity sendAuthCode(String phone,String code,long sel);
	
	public abstract void saveMsg(long se,SmsEntity see );
}
