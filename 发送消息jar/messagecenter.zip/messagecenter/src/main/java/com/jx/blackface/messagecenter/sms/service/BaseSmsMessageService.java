package com.jx.blackface.messagecenter.sms.service;

import com.jx.blackface.messagecenter.sms.entity.SmsEntity;

public abstract class BaseSmsMessageService extends BaseMessageService{

	public abstract SmsEntity sendMessage(String template, String phone,String[] text,long sel);

}
