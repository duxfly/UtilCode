package com.jx.service.messagecenter.memcache;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.jx.service.messagecenter.common.StringValue;

/* ========================================================
 * 北京五八信息技术有限公司
 * 日 期：2013-1-17 下午02:00:36
 * 作 者：张艳伟
 * 版 本：1.0.0
 * 类说明：
 * 缓存接口定义类
 * ========================================================
 * 修订日期     修订人    描述
 * 2013-1-17   张艳伟    创建
 */
public abstract class CacheProvider implements Serializable{

	private static final long serialVersionUID = 1L;

	/**
	 * mem缓存文件路径
	 */
	public static final String MEMCACHECONFIG = StringValue.getPath()+ "/config/pagecache_memcache.xml";
	
	
	/**
	 * 默认1小时
	 */
	public static final int DEFAULT_TIMEOUT = 3600000;
	
	/**
	 * 是否统计缓存访问次数
	 */
	public static final boolean IS_COUNT_CACHE = false;
	public static Map<String, Integer> cacheSetCountMap = new LinkedHashMap<String, Integer>();
	public static Map<String, Integer> cacheGetCountMap = new LinkedHashMap<String, Integer>();
	
	
	/**
	 * 根据key从缓存中取得数据
	 * @param key
	 * @return
	 */
	abstract public Object get(String key);
	
	abstract public <T> Map<String, T> gets(String[] keys);
	
	/**
	 * 放入缓存中，默认缓存时间是24小时
	 * @param key
	 * @param obj
	 */
	abstract public boolean set(String key,Object value);
	
	/**
	 * 放入缓存中，设定缓存时间
	 * @param key
	 * @param obj
	 * @param seconds
	 */
	abstract public boolean set(String key,Object value,int seconds);
	
	/**
	 * 移除单个缓存
	 * @param keys
	 */
	abstract public boolean removeone(String key);
	
	
	/**
	 * 移除缓存
	 * @param keys
	 */
	abstract public void remove(String[] keys); 
	//批量获取缓存数据
	abstract public <T> List<T> getList(String[] keys);
	
	/**
	 * 统计缓存次数   type:  1:set  2:set
	 * @param type
	 * @param key
	 */
	/*
	public static void cacheCount(int type, String key){
		if(IS_COUNT_CACHE){
			if(1==type){
				Object object = cacheSetCountMap.get(key);
				if(object!=null){
					cacheSetCountMap.put(key, ((Integer)object)+1);
				}else{
					cacheSetCountMap.put(key, 1);
				}
			}else {
				Object object = cacheGetCountMap.get(key);
				if(object!=null){
					cacheGetCountMap.put(key, ((Integer)object)+1);
				}else{
					cacheGetCountMap.put(key, 1);
				}
			}
		}
	}*/
	
	public static String getCacheKey(String key){
		return key;
	}
	
	public static String[] getCacheKeyArr(String[] keys){
		ArrayList<String> keyList =new ArrayList<String>();
		for (String key : keys) {
			keyList.add(getCacheKey(key));
		}
		return keyList.toArray(new String[keys.length]);
	}
	
}
