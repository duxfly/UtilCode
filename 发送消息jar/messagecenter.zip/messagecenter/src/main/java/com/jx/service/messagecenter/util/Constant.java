/**
 * 
 */

package com.jx.service.messagecenter.util;

import java.util.Properties;



/**
 * simple introduction
 *
 * <p>detailed comment</p>
 * @author chuxuebao 2015年12月11日
 * @see
 * @since 1.0
 */

public class Constant {
	
	public static String serviceMode;
	
	static{
		Properties configFile = ConfigFileUtils.getConfigFile(Constant.MSG_CONSTANT_FILE);
		serviceMode = configFile.getProperty(Constant.SERVICE_MODE_KEY, Constant.SERVICE_MODE_TEST); // 默认测试环境
	}
	
	/**
	 * 常量配置文件
	 */
	public static final String MSG_CONSTANT_FILE = "msgConstant.properties";
	/**
	 * 服务模式：test，测试环境；work：正式环境
	 */
	public static final String SERVICE_MODE_KEY = "serviceMode";
	public static final String SERVICE_MODE_TEST = "test";
	public static final String SERVICE_MODE_WORK = "work";
	
	
	
}
