package com.jx.blackface.messagecenter.core.entity;

import java.util.Date;

import com.bj58.sfft.utility.dao.annotation.Column;
import com.bj58.sfft.utility.dao.annotation.Id;
import com.bj58.sfft.utility.dao.annotation.Table;
import com.jx.spat.gaea.serializer.component.annotation.GaeaMember;
import com.jx.spat.gaea.serializer.component.annotation.GaeaSerializable;

@GaeaSerializable
@Table(name = "t_call_list")
public class CallEntity {
	@GaeaMember
	@Id(insertable = true)
	@Column(name = "callid")
	private long callid;

	@GaeaMember
	@Column(name = "userid")
	private long userid;

	@GaeaMember
	@Column(name = "orderid")
	private long orderid;

	@GaeaMember
	@Column(name = "fromnumber")
	private long fromnumber;

	@GaeaMember
	@Column(name = "tonumber")
	private long tonumber;

	@GaeaMember
	@Column(name = "totaltime")
	private long totaltime;

	@GaeaMember
	@Column(name = "callstate")
	private short callstate;
	@GaeaMember
	@Column(name = "receivestate")
	private short receivestate;

	@GaeaMember
	@Column(name = "usetime")
	private long usetime;

	@GaeaMember
	@Column(name = "havetimes")
	private long havetimes;

	@GaeaMember
	@Column(name = "starttime")
	private Date starttime;
	@GaeaMember
	@Column(name = "endtime")
	private Date endtime;
	
	@GaeaMember
	@Column(name = "voicerecord")
	private String voicerecord;
	@GaeaMember
	@Column(name = "voiceovertime")
	private Date voiceovertime;
	
	@GaeaMember
	@Column(name = "lastcallid")
	private long lastcallid;

	@GaeaMember
	@Column(name = "addtime")
	private long addtime;
	@GaeaMember
	@Column(name = "updatetime")
	private long updatetime;
	
	@GaeaMember
	@Column(name = "respcode")
	private String respcode;
	
	@GaeaMember
	@Column(name = "originalid")
	private String originalid;
	
	@GaeaMember
	@Column(name = "providerid")
	private String providerid;
	
	@GaeaMember
	@Column(name = "servicestep")
	private String servicestep;

	
	@GaeaMember
	@Column(name = "comments")
	private String comments;

	
	@GaeaMember
	@Column(name = "customerid")
	private long customerid;

	@GaeaMember
	@Column(name = "calltype")
	private short calltype;
	
	public long getCallid() {
		return callid;
	}

	public void setCallid(long callid) {
		this.callid = callid;
	}

	public long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}

	public long getOrderid() {
		return orderid;
	}

	public void setOrderid(long orderid) {
		this.orderid = orderid;
	}

	public long getFromnumber() {
		return fromnumber;
	}

	public void setFromnumber(long fromnumber) {
		this.fromnumber = fromnumber;
	}

	public long getTonumber() {
		return tonumber;
	}

	public void setTonumber(long tonumber) {
		this.tonumber = tonumber;
	}

	public long getTotaltime() {
		return totaltime;
	}

	public void setTotaltime(long totaltime) {
		this.totaltime = totaltime;
	}

	public short getCallstate() {
		return callstate;
	}

	public void setCallstate(short callstate) {
		this.callstate = callstate;
	}

	public short getReceivestate() {
		return receivestate;
	}

	public void setReceivestate(short receivestate) {
		this.receivestate = receivestate;
	}

	public long getUsetime() {
		return usetime;
	}

	public void setUsetime(long usetime) {
		this.usetime = usetime;
	}

	public long getHavetimes() {
		return havetimes;
	}

	public void setHavetimes(long havetimes) {
		this.havetimes = havetimes;
	}

	public Date getStarttime() {
		return starttime;
	}

	public void setStarttime(Date starttime) {
		this.starttime = starttime;
	}

	public Date getEndtime() {
		return endtime;
	}

	public void setEndtime(Date endtime) {
		this.endtime = endtime;
	}

	public long getLastcallid() {
		return lastcallid;
	}

	public void setLastcallid(long lastcallid) {
		this.lastcallid = lastcallid;
	}

	public long getAddtime() {
		return addtime;
	}

	public void setAddtime(long addtime) {
		this.addtime = addtime;
	}

	public long getUpdatetime() {
		return updatetime;
	}

	public void setUpdatetime(long updatetime) {
		this.updatetime = updatetime;
	}

	public String getRespcode() {
		return respcode;
	}

	public void setRespcode(String respcode) {
		this.respcode = respcode;
	}

	public String getOriginalid() {
		return originalid;
	}

	public void setOriginalid(String originalid) {
		this.originalid = originalid;
	}

	public String getProviderid() {
		return providerid;
	}

	public void setProviderid(String providerid) {
		this.providerid = providerid;
	}

	public String getServicestep() {
		return servicestep;
	}

	public void setServicestep(String servicestep) {
		this.servicestep = servicestep;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public long getCustomerid() {
		return customerid;
	}

	public void setCustomerid(long customerid) {
		this.customerid = customerid;
	}

	public String getVoicerecord() {
		return voicerecord;
	}

	public void setVoicerecord(String voicerecord) {
		this.voicerecord = voicerecord;
	}

	public Date getVoiceovertime() {
		return voiceovertime;
	}

	public void setVoiceovertime(Date voiceovertime) {
		this.voiceovertime = voiceovertime;
	}

	public short getCalltype() {
		return calltype;
	}

	public void setCalltype(short calltype) {
		this.calltype = calltype;
	}

	
}
