package com.jx.service.messagecenter.common;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jx.spat.gaea.server.util.config.PropertiesHelper;


public class Constants {

	public static final String path = "/opt/gaea/wx/wxconfig.properties";//WF.getConfigFolder() + WF.getNamespace()+"/wxconfig.properties";
	public static Properties pro = new Properties();
	
	static{
		InputStream ins = null;
		try {
			System.out.println("wx url is "+path);
			ins = new BufferedInputStream(new FileInputStream(path));
			pro.load(ins);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static final String order_submit_module_id = 
			//"eairir1rjH9pNwSLwtFlJO6Dzd0lwFkkv5H6L52fGA0";//易车
			pro.getProperty("submitmodueid");//"20ZZj0K2uaIYaWD0vA7dMFkacME804FkWlYYiorsyPE";//小微
	public static final String order_cancel_module_id = 
			//"_cQpJXo2SlV7X7HMDN5jfx7odJHF9aF8rEeOGR7f2OY";//易车
			pro.getProperty("submitconcelid");//"d5l2hoA2-HxoZ5mxi0B5YSGFv7F9eaU4NugmnUpVaMU";//小微
	public static final String order_update_state_id = 
			//"uWKge33GLvJgxKBj9VMoonRKEjr5bQtnCsKGF4csmFQ";//易车
			pro.getProperty("submitupdateid");//"uANHJ8sRe4Ih-mbkFdHX7nORUab6flXHbMYMJqqJ0bM";//小微
	
	
	public final static String weixin_appid = pro.getProperty("appid");
	public final static String weixin_secid = pro.getProperty("appsecretid");
	//public final static String weixin_token_str = pro.getProperty("weixin_token_str");
	
	
	public static int SERVER_ID  = 1;
	public static long ID_BEGIN_TIME = 1309449600000L;
	public static int DB_COUNT = 1;
	
	public static int DB_THREAD_TIMEOUT = 5000;

	

	private static final Log logger = LogFactory.getLog(Constants.class);

	static {
		try {
			String myFile = StringValue.getPath() + "/config/mysql.properties";
			logger.info("mysql.properties path:" + myFile);

			PropertiesHelper ph = new PropertiesHelper(myFile);
			DB_THREAD_TIMEOUT = ph.getInt("db_thread_timeout");
			SERVER_ID = ph.getInt("server_id");
			DB_COUNT = ph.getInt("db_count");

			logger.info("db_thread_timeout:" + DB_THREAD_TIMEOUT);
			logger.info("server_id:" + SERVER_ID);
			logger.info("db_count:" + DB_COUNT);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
