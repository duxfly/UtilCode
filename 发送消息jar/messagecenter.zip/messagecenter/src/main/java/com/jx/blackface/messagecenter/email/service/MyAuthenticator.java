package com.jx.blackface.messagecenter.email.service;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class MyAuthenticator extends Authenticator {
	 private String userName; 
     private String password; 
 
     public MyAuthenticator(String userName, String password){ 
         this.userName= userName; 
         this.password= password; 
     } 
     
     public String getUserName() {
		return userName;
	}

	@Override 
     protected PasswordAuthentication getPasswordAuthentication() { 
         return new PasswordAuthentication(userName, password); 
     } 

}
