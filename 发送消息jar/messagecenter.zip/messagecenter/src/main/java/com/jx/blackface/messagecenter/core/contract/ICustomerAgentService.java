package com.jx.blackface.messagecenter.core.contract;

import java.util.List;

import com.jx.blackface.messagecenter.core.entity.CustomerAgentEntity;
import com.jx.spat.gaea.server.contract.annotation.OperationContract;
import com.jx.spat.gaea.server.contract.annotation.ServiceContract;

@ServiceContract
public interface ICustomerAgentService {
	@OperationContract
	public long addCustomerAgentEntity(CustomerAgentEntity mbe)throws Exception;
	@OperationContract
	public CustomerAgentEntity loadCustomerAgentEntity(long mid)throws Exception;
	@OperationContract
	public List<CustomerAgentEntity> getCallListbyPage(String condition,int pageindex,int pagesize,String orderby)throws Exception;
	@OperationContract
	public int getCustomerAgentCountByCondition(String condition)throws Exception;
	@OperationContract
	public void updateCustomerAgent(CustomerAgentEntity mbe)throws Exception;
	@OperationContract
	public CustomerAgentEntity getOneIdleCustomerAgent()throws Exception;
	@OperationContract
	public void delCustomerAgentEntity(long mbeid)throws Exception;
}
