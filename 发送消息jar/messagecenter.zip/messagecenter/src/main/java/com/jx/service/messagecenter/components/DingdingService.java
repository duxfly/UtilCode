/**
 * 
 */

package com.jx.service.messagecenter.components;

import com.jx.service.messagecenter.contract.IDingdingService;
import com.jx.service.messagecenter.dingding.auth.AuthHelper;
import com.jx.spat.gaea.server.contract.annotation.ServiceBehavior;



/**
 * simple introduction
 *
 * <p>detailed comment</p>
 * @author chuxuebao 2015年12月5日
 * @see
 * @since 1.0
 */
@ServiceBehavior
public class DingdingService implements IDingdingService {

	@Override
	public String getAccessToken() throws Exception {
		
		return AuthHelper.getAccessToken();
	}

	
}
