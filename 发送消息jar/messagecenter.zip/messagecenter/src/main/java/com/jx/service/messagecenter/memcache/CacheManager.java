package com.jx.service.messagecenter.memcache;

import java.util.Map;



/* ========================================================
 * 北京五八信息技术有限公司
 * 日 期：2013-1-17 下午02:35:50
 * 作 者：张艳伟
 * 版 本：1.0.0
 * 类说明：
 * 缓存工具调用类
 * ========================================================
 * 修订日期     修订人    描述
 * 2013-1-17   张艳伟    创建
 */
public class CacheManager {
	
	private static CacheProvider CACHE_PROVIDER = null;
	
	static{
		init();
	}
	
	public static void init() {
		if(CACHE_PROVIDER==null){
			synchronized (CacheManager.class) {
				if(CACHE_PROVIDER==null){
					CACHE_PROVIDER = new SpatMemCacheProvider();
				}
			}
		}
	}
	
	/**
	 * 根据key从缓存中取得数据
	 * @param key
	 * @return
	 */
	public static Object get(String key){
		if(CACHE_PROVIDER==null)
			init();
		return CACHE_PROVIDER.get(key);
		
	}
	
	public static <T> Map<String, T> getS(String[] keys){
		if(CACHE_PROVIDER==null)
			init();
		return CACHE_PROVIDER.gets(keys);
	}
	
	/**
	 * 放入缓存中，默认缓存时间是24小时
	 * @param key
	 * @param obj
	 */
	public static boolean set(String key,Object value){
		if(CACHE_PROVIDER==null)
			init();
		return CACHE_PROVIDER.set(key, value);
	}
	
	/**
	 * 放入缓存中，设定缓存时间
	 * @param key
	 * @param obj
	 * @param seconds
	 */
	public static boolean set(String key,Object value,int seconds){
		if(CACHE_PROVIDER==null)
			init();
		return CACHE_PROVIDER.set(key, value, seconds);
	}
	
	/**
	 * 移除单个缓存
	 * @param keys
	 */
	public static boolean removeone(String key){
		if(CACHE_PROVIDER==null)
			init();
		return CACHE_PROVIDER.removeone(key);
	}
	
	
	
	/**
	 * 移除缓存
	 * @param keys
	 */
	public static void remove(String[] keys){
		if(CACHE_PROVIDER==null)
			init();
		CACHE_PROVIDER.remove(keys);
	} 
	
}
