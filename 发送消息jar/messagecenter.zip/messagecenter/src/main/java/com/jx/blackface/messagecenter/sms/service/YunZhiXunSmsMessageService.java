package com.jx.blackface.messagecenter.sms.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alipay.sign.MD5;
import com.jx.blackface.messagecenter.sms.entity.SmsEntity;
import com.jx.service.messagecenter.dingding.exception.OApiException;
import com.jx.service.messagecenter.entity.AuthMsgEntity;
import com.jx.service.messagecenter.util.DateUtils;

public class YunZhiXunSmsMessageService extends BaseSmsMessageService {

	// 帐号sid
	private static final String ACCOUNT_SID = "f0d9b7600a5a8b9751b102abd8bd046e";
	// 帐号token
	private static final String AUTH_TOKEN = "1ddf7d3a245ddcd9d3954ff8fdccfe27";
	// RESTURL
	private static final String REST_URL = "https://api.ucpaas.com";
	// APP_ID
	private static final String APP_ID = "c17c0a5cf2494c3384ec71191978cd00";
	// 验证码模版
	private static final String AUTHCODE_TEMP = "17153";
	// 版本号
	private static final String VERSION = "/2014-06-30";
	// 模版短信地址
	private static final String SMSTEMPLATE = REST_URL + VERSION + "/Accounts/" + ACCOUNT_SID + "/Messages/templateSMS";

	private static final Base64 base64 = new Base64();
	private static final short CHANNEL = 3;
	@Override
	public SmsEntity sendMessage(String template, String phone, String[] text, long sel) {
		// TODO Auto-generated method stub
		System.out.println(template + "--" + phone + "--" + text[0]);

		String timestamp = DateUtils.getFormatDateStr(new Date(), DateUtils.DATA_FORMAT_YYYYMMDDHHMMSS);
		String sig = ACCOUNT_SID + AUTH_TOKEN + timestamp;
		System.out.println(sig);
		sig = MD5.sign(sig, "", "UTF-8").toUpperCase();
		JSONObject sms = new JSONObject();
		sms.put("appId", APP_ID);
		sms.put("templateId", template);
		sms.put("to", phone);
		String param = "";
		if (text.length > 0) {
			for (int i = 0; i < text.length; i++) {
				if (i != 0) {
					param += ",";
				}
				param = param + text[i];
			}
		}
		sms.put("param", param);
		JSONObject body = new JSONObject();
		body.put("templateSMS", sms);
		System.out.println(JSON.toJSONString(body));
		System.out.println(timestamp + "--" + sig);
		String url = SMSTEMPLATE + "?sig=" + sig;

		String auth = ACCOUNT_SID + ":" + timestamp;
		System.out.println(auth);
		auth = base64.encodeToString(auth.getBytes());
		System.out.println(auth);
		Map<String, String> header = new HashMap<String, String>();
		header.put("Authorization", auth);
		JSONObject ret = null;
		try {
			ret = SMSHttpHelper.httpPost(url, body, header);
		} catch (OApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(ret);
		if (ret.containsKey("resp")) {
			JSONObject result = ret.getJSONObject("resp");
			SmsEntity se = new SmsEntity();
			se.setChannel(CHANNEL);
			se.setRespCode(result.getString("respCode"));
			se.setText(param);
			if (result.containsKey("templateSMS")){
				result = result.getJSONObject("templateSMS");
				if (result.containsKey("smsId"))
					se.setSmsId(result.getString("smsId"));
				if (result.containsKey("createDate"))
					se.setCreateDate(result.getString("createDate"));
			}
			if(sel!=0)saveMsg(sel, se);
			return se;
		} else {
			return null;
		}
	}

	public static void main(String[] args) {
		BaseSmsMessageService x = new YunZhiXunSmsMessageService();
		SmsEntity e = x.sendAuthCode("13313169156", "341278",0);
		System.out.println(e);
	}

	public SmsEntity sendAuthCode(String phone, String code,long sel) {
		
		return sendMessage(AUTHCODE_TEMP, phone, new String[] { code, "15分钟" },sel);
	}

	@Override
	public void saveMsg(long se, SmsEntity see) {
		try {
			AuthMsgEntity ame = imss.getMsgEntityById(se);
			if (ame != null ) {
				ame.setMsgid(see.getSmsId());
				ame.setMsgchannel(see.getChannel());
				if("000000".equals(see.getRespCode())){
					ame.setSendstate((short)1);
				}else{
					ame.setSendstate((short)0);
				}
				ame.setRespmessage(see.getOthMsg());
				ame.setRespcode(see.getRespCode());
				if(StringUtils.isNotBlank(see.getCreateDate())){
					ame.setSendtimestamp(DateUtils.getDateFromStrYYYYMMDDHHMMSS(see.getCreateDate()));
				}
				imss.updateMsgEntity(ame);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
