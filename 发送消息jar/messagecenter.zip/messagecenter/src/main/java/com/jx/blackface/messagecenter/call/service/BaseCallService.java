package com.jx.blackface.messagecenter.call.service;



import com.jx.blackface.messagecenter.call.entity.CallbackEntity;
import com.jx.blackface.messagecenter.core.components.CallService;
import com.jx.blackface.messagecenter.core.contract.ICallService;


public abstract class BaseCallService{

	// 显号号码
	public static final String DISPNUMBER010 = "01084463639";
	
	public static ICallService  imss = new CallService();

	public abstract CallbackEntity putcall(long from,long to,long time, long sel);
	
	public abstract CallbackEntity callcancel(long sel);
	
	public abstract void saveMsg(long se,CallbackEntity see );
}
