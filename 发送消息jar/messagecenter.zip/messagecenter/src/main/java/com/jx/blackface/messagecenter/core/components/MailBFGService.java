package com.jx.blackface.messagecenter.core.components;

import java.util.Date;
import java.util.List;

import com.jx.blackface.messagecenter.core.contract.IMailBFGService;
import com.jx.blackface.messagecenter.core.entity.MailBFGEntity;
import com.jx.service.messagecenter.common.IDHelper;
import com.jx.spat.gaea.server.contract.annotation.ServiceBehavior;

@ServiceBehavior
public class MailBFGService extends NewCommonService implements IMailBFGService {

	@Override
	public long addMessageEntity(MailBFGEntity mbe) throws Exception {
		long resid = 0;
		long pid = IDHelper.getUniqueID();
		if (mbe != null) {
			mbe.setMailid(pid);
			mbe.setAddtime(new Date().getTime());
			insertObjec(mbe);
			resid = pid;
		}
		return resid;
	}

	@Override
	public MailBFGEntity loadMailEntity(long mid) throws Exception {
		MailBFGEntity mbe = (MailBFGEntity) getObjectByid(mid, MailBFGEntity.class);
		return mbe;
	}

	@Override
	public List<MailBFGEntity> getMailListbypage(String condition, int pageindex, int pagesize, String orderby)
			throws Exception {

		return (List<MailBFGEntity>) getListBypage(MailBFGEntity.class, condition, pageindex, pagesize, orderby);
	}

	@Override
	public int getMailcountBycondition(String condition) throws Exception {
		return getCountBycondition(MailBFGEntity.class, condition);
	}

	@Override
	public void updateMail(MailBFGEntity mbe) throws Exception {
		updateObject(mbe);

	}
}
