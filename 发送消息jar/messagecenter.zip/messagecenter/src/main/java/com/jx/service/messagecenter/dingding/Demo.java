/**
 * 
 */

package com.jx.service.messagecenter.dingding;

import com.alibaba.fastjson.JSON;
import com.jx.service.messagecenter.dingding.auth.AuthHelper;
import com.jx.service.messagecenter.dingding.message.LightAppMessageDelivery;
import com.jx.service.messagecenter.dingding.message.MessageHelper;
import com.jx.service.messagecenter.dingding.message.OAMessage;
import com.jx.service.messagecenter.dingding.message.MessageHelper.Receipt;



/**
 * simple introduction
 *
 * <p>detailed comment</p>
 * @author chuxuebao 2015年12月5日
 * @see
 * @since 1.0
 */

public class Demo {

	public static void main(String[] args) throws Exception {
		String content = "{ \"message_url\": \"http://www.lvzheng.com/dingding/task/123123123\", \"head\": { \"bgcolor\": \"FFCC0000\" }, \"body\": { \"title\": \"新任务\", \"form\": [ { \"key\": \"任务名称：\", \"value\": \"张三\" }, { \"key\": \"公司名称：\", \"value\": \"30\" }, { \"key\": \"应完成时间：\", \"value\": \"30\" } ], \"content\": \"请及时处理该任务任务哦。\"  } }";
		System.out.println(content);
		// 获取access token
		String accessToken = AuthHelper.getAccessToken();
		//创建oa消息
		OAMessage oaMessage = JSON.parseObject(content, OAMessage.class);
		LightAppMessageDelivery lightAppMessageDelivery = new LightAppMessageDelivery("", "", "");
		lightAppMessageDelivery.withMessage(oaMessage);
		Receipt send = MessageHelper.send(accessToken, lightAppMessageDelivery);
		if(send != null){
			return;
		}
		log("成功发送 微应用oa消息");
	}
	
	private static void log(Object... msgs) {
		StringBuilder sb = new StringBuilder();
		for (Object o : msgs) {
			if (o != null) {
				sb.append(o.toString());
			}
		}
		System.out.println(sb.toString());
	}
}
