package com.jx.service.messagecenter.entity;

import com.jx.spat.gaea.serializer.component.annotation.GaeaMember;
import com.jx.spat.gaea.serializer.component.annotation.GaeaSerializable;

@GaeaSerializable
public class OrderMessageEntity {
	@GaeaMember
	private long WX_ORDERID;
	@GaeaMember
	private String WX_SERVER_STR;
	@GaeaMember
	private String WX_COMPANY_NAME;
	@GaeaMember
	private long WX_EMPID;
	@GaeaMember
	private String WX_USER_NAME;
	@GaeaMember
	private long uid;
	@GaeaMember
	private String WX_FANS_PHONE;
	@GaeaMember
	private String openid;
	@GaeaMember
	private long actioncode;
	@GaeaMember
	private String WX_FW_NAME;
	@GaeaMember
	private String WX_FW_PHONE;
	@GaeaMember
	private String emopenid;
	@GaeaMember
	private float WX_PAY_BOOKMONEY;
	@GaeaMember
	private String WX_PRE_FW_NAME;
	@GaeaMember
	private float WX_PAY_NEEDMONEY;
	@GaeaMember
	private float WX_PAY_TOTALMONEY;//totalmoney;
	@GaeaMember
	private String cwopenid;
	@GaeaMember
	private String orderstatestr;
	@GaeaMember
	private String WX_JZ_ZHOUQI;
	@GaeaMember
	private String WX_ADD_MESSAGE;
	@GaeaMember
	private String WX_CURR_CONTENT;
	@GaeaMember
	private String WX_NEXT_CONTENT;
	
	
	public String getWX_CURR_CONTENT() {
		return WX_CURR_CONTENT;
	}
	public void setWX_CURR_CONTENT(String wX_CURR_CONTENT) {
		WX_CURR_CONTENT = wX_CURR_CONTENT;
	}
	public String getWX_NEXT_CONTENT() {
		return WX_NEXT_CONTENT;
	}
	public void setWX_NEXT_CONTENT(String wX_NEXT_CONTENT) {
		WX_NEXT_CONTENT = wX_NEXT_CONTENT;
	}
	public String getWX_ADD_MESSAGE() {
		return WX_ADD_MESSAGE;
	}
	public void setWX_ADD_MESSAGE(String wX_ADD_MESSAGE) {
		WX_ADD_MESSAGE = wX_ADD_MESSAGE;
	}
	public String getWX_JZ_ZHOUQI() {
		return WX_JZ_ZHOUQI;
	}
	public void setWX_JZ_ZHOUQI(String wX_JZ_ZHOUQI) {
		WX_JZ_ZHOUQI = wX_JZ_ZHOUQI;
	}
	public String getOrderstatestr() {
		return orderstatestr;
	}
	public void setOrderstatestr(String orderstatestr) {
		this.orderstatestr = orderstatestr;
	}
	public String getEmopenid() {
		return emopenid;
	}
	public void setEmopenid(String emopenid) {
		this.emopenid = emopenid;
	}
	public String getCwopenid() {
		return cwopenid;
	}
	public void setCwopenid(String cwopenid) {
		this.cwopenid = cwopenid;
	}
	public String getOpenid() {
		return openid;
	}
	public void setOpenid(String openid) {
		this.openid = openid;
	}

	
	public long getWX_ORDERID() {
		return WX_ORDERID;
	}
	public void setWX_ORDERID(long wX_ORDERID) {
		WX_ORDERID = wX_ORDERID;
	}
	public String getWX_SERVER_STR() {
		return WX_SERVER_STR;
	}
	public void setWX_SERVER_STR(String wX_SERVER_STR) {
		WX_SERVER_STR = wX_SERVER_STR;
	}
	public String getWX_COMPANY_NAME() {
		return WX_COMPANY_NAME;
	}
	public void setWX_COMPANY_NAME(String wX_COMPANY_NAME) {
		WX_COMPANY_NAME = wX_COMPANY_NAME;
	}
	public long getWX_EMPID() {
		return WX_EMPID;
	}
	public void setWX_EMPID(long wX_EMPID) {
		WX_EMPID = wX_EMPID;
	}
	public String getWX_USER_NAME() {
		return WX_USER_NAME;
	}
	public void setWX_USER_NAME(String wX_USER_NAME) {
		WX_USER_NAME = wX_USER_NAME;
	}
	public String getWX_FANS_PHONE() {
		return WX_FANS_PHONE;
	}
	public void setWX_FANS_PHONE(String wX_FANS_PHONE) {
		WX_FANS_PHONE = wX_FANS_PHONE;
	}
	public String getWX_FW_NAME() {
		return WX_FW_NAME;
	}
	public void setWX_FW_NAME(String wX_FW_NAME) {
		WX_FW_NAME = wX_FW_NAME;
	}
	public String getWX_FW_PHONE() {
		return WX_FW_PHONE;
	}
	public void setWX_FW_PHONE(String wX_FW_PHONE) {
		WX_FW_PHONE = wX_FW_PHONE;
	}
	public float getWX_PAY_BOOKMONEY() {
		return WX_PAY_BOOKMONEY;
	}
	public void setWX_PAY_BOOKMONEY(float wX_PAY_BOOKMONEY) {
		WX_PAY_BOOKMONEY = wX_PAY_BOOKMONEY;
	}
	public String getWX_PRE_FW_NAME() {
		return WX_PRE_FW_NAME;
	}
	public void setWX_PRE_FW_NAME(String wX_PRE_FW_NAME) {
		WX_PRE_FW_NAME = wX_PRE_FW_NAME;
	}
	public float getWX_PAY_NEEDMONEY() {
		return WX_PAY_NEEDMONEY;
	}
	public void setWX_PAY_NEEDMONEY(float wX_PAY_NEEDMONEY) {
		WX_PAY_NEEDMONEY = wX_PAY_NEEDMONEY;
	}
	public float getWX_PAY_TOTALMONEY() {
		return WX_PAY_TOTALMONEY;
	}
	public void setWX_PAY_TOTALMONEY(float wX_PAY_TOTALMONEY) {
		WX_PAY_TOTALMONEY = wX_PAY_TOTALMONEY;
	}
	public long getUid() {
		return uid;
	}
	public void setUid(long uid) {
		this.uid = uid;
	}
	public long getActioncode() {
		return actioncode;
	}
	public void setActioncode(long actioncode) {
		this.actioncode = actioncode;
	}
	
	
}
