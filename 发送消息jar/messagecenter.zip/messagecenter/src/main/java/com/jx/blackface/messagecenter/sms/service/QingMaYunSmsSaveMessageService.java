package com.jx.blackface.messagecenter.sms.service;

import java.util.Date;
import java.util.List;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alipay.sign.MD5;
import com.jx.service.messagecenter.components.MoblieSmsService;
import com.jx.service.messagecenter.contract.IMoblieSmsService;
import com.jx.service.messagecenter.dingding.exception.OApiException;
import com.jx.service.messagecenter.entity.AuthMsgEntity;
import com.jx.service.messagecenter.util.DateUtils;

public class QingMaYunSmsSaveMessageService implements Runnable{

	public static IMoblieSmsService imss = new MoblieSmsService();
	// 帐号sid
//	private static final String ACCOUNT_SID = "929c8a68981a4808942a58402b0ecf3b";
	private static final String ACCOUNT_SID = "d66c3ae63609429886ba520d2bb8ad8b";
	// 帐号token
//	private static final String AUTH_TOKEN = "0a9364f81c1640619fb14e89334df294";
	private static final String AUTH_TOKEN = "b0a79d202a1849f3a618cc40b76c59f8";
	// RESTURL
//	private static final String REST_URL = "https://api.qingmayun.com";
	private static final String REST_URL = "https://api.miaodiyun.com";
	// APP_ID
//	private static final String APP_ID = "de7480009d3049acaa19a721fcc59d25";
	// 验证码模版
	private static final String AUTHCODE_TEMP = "14311723";
	// 版本号
	private static final String VERSION = "/20150822";
	// 模版短信地址
	private static final String SMSTEMPLATE = REST_URL + VERSION + "/emailSMS/querySendResult";
	private static final short CHANNEL = 2;

	public String smsId;
	public QingMaYunSmsSaveMessageService(String smsId){
		this.smsId = smsId;
	}
	public void refreshMessage(String smsId) throws Exception {
		// TODO Auto-generated method stub

		String timestamp = DateUtils.getFormatDateStr(new Date(), DateUtils.DATA_FORMAT_YYYYMMDDHHMMSS);
		String sig = ACCOUNT_SID + AUTH_TOKEN + timestamp;
		System.out.println(sig);
		sig = MD5.sign(sig, "", "UTF-8");
		JSONObject sms = new JSONObject();
//		sms.put("appId", APP_ID);
		sms.put("smsId", smsId);

		JSONObject body = new JSONObject();
		body.put("querySendResult", sms);
		System.out.println(JSON.toJSONString(body));
		System.out.println(timestamp + "--" + sig);
		String url = SMSTEMPLATE + "?sig=" + sig + "&timestamp=" + timestamp;
		JSONObject ret = null;
		try {
			ret = SMSHttpHelper.httpPost(url, body);
		} catch (OApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(ret);
		if (ret.containsKey("result")) {
			JSONObject result = ret.getJSONObject("result");
			if (result.containsKey("respCode") && "00000".equals(result.getString("respCode"))) {
				JSONArray ja = result.getJSONArray("smsBox");
				if (ja != null && ja.size() > 0) {
					result = ja.getJSONObject(0);
					List<AuthMsgEntity> lame = imss.getMsgEntity("msgid='" + smsId + "'", 1, 1, "");
					if (lame == null || lame.size() == 0) {
						Thread.sleep(2000);
						lame = imss.getMsgEntity("msgid='" + smsId + "'", 1, 1, "");
					}
					if (lame != null && lame.size() > 0) {
						AuthMsgEntity ame = lame.get(0);
						ame.setBackstate(Short.parseShort(result.getString("status")));
						ame.setBacktimestamp(new Date());
						ame.setRespmessage(result.getString("respMessage"));
						System.out.println(ame);
						imss.updateMsgEntity(ame);
					}
				}
			}

		}
	}

	@Override
	public void run() {
		try {
			refreshMessage(smsId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


}
