package com.jx.blackface.messagecenter.sms.service;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.lang.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import com.jx.blackface.messagecenter.sms.entity.SmsEntity;
import com.jx.service.messagecenter.entity.AuthMsgEntity;
import com.jx.service.messagecenter.util.DateUtils;

public class ShanghaiSmsMessageService extends BaseSmsMessageService{

	// 帐号sid
	private static final String ACCOUNT = "cf_xiaoweilz";
	// 帐号token
	private static final String PASSWORD = "xiaoweiLvzheng";
	// RESTURL
	private static final String POSTURL = "http://121.199.16.178";
	
	// 模版短信地址
	private static final String SMSTEMPLATE = POSTURL + "/webservice/sms.php?method=Submit";
	private static final short CHANNEL = 1;
	@Override
	public SmsEntity sendMessage(String template, String phone, String[] text,long sel) {
		
		HttpClient client = new HttpClient(); 
		PostMethod method = new PostMethod(SMSTEMPLATE); 
		client.getParams().setContentCharset("UTF-8");
		method.setRequestHeader("ContentType","application/x-www-form-urlencoded;charset=UTF-8");

		NameValuePair[] data = {//提交短信
			    new NameValuePair("account", ACCOUNT), 
			    new NameValuePair("password", PASSWORD), //密码可以使用明文密码或使用32位MD5加密
			    new NameValuePair("mobile", phone), 
			    new NameValuePair("content", text[0]),
		};
		method.setRequestBody(data);
		SmsEntity se = null;
		try {
			client.executeMethod(method);	
			String SubmitResult =method.getResponseBodyAsString();
			Document doc = DocumentHelper.parseText(SubmitResult); 
			Element root = doc.getRootElement();
			String code = root.elementText("code");	
			String msg = root.elementText("msg");	
			String smsid = root.elementText("smsid");	
			se = new SmsEntity();
			se.setChannel(CHANNEL);
			se.setRespCode(code);
			se.setText(text[0]);
			se.setSmsId(smsid);
			se.setOthMsg(msg);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		if(sel>0)saveMsg(sel, se);
        return se;
		
	}

	public static void main(String[] args) {
		BaseSmsMessageService x = new ShanghaiSmsMessageService();
		SmsEntity e = x.sendAuthCode("18810777655", "005383",0);
		System.out.println(e);
	}

	public SmsEntity sendAuthCode(String phone, String code,long sel) {
		
		String msg = "您的验证码是："+code+"(15分钟有效)。";
		return sendMessage(null, phone, new String[] { msg},sel);
	}

	@Override
	public void saveMsg(long se, SmsEntity see) {
		try {
			AuthMsgEntity ame = imss.getMsgEntityById(se);
			if (ame != null ) {
				ame.setMsgid(see.getSmsId());
				ame.setMsgchannel(see.getChannel());
				if("2".equals(see.getRespCode())){
					ame.setSendstate((short)1);
				}else{
					ame.setSendstate((short)0);
				}
				ame.setRespmessage(see.getOthMsg());
				ame.setRespcode(see.getRespCode());
				if(StringUtils.isNotBlank(see.getCreateDate())){
					ame.setSendtimestamp(DateUtils.getDateFromStr(see.getCreateDate()));
				}
				imss.updateMsgEntity(ame);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
