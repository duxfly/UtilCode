package com.jx.blackface.messagecenter.core.entity;

import com.bj58.sfft.utility.dao.annotation.Column;
import com.bj58.sfft.utility.dao.annotation.Id;
import com.bj58.sfft.utility.dao.annotation.Table;
import com.jx.spat.gaea.serializer.component.annotation.GaeaMember;
import com.jx.spat.gaea.serializer.component.annotation.GaeaSerializable;

@GaeaSerializable
@Table(name = "t_lvz_email_list")
public class EmailListEntity {
	@GaeaMember
	@Id(insertable = true)
	@Column(name = "Id")
	private long id;

	@GaeaMember
	@Column(name = "addtime")
	private long addtime;

	
	@GaeaMember
	@Column(name = "state")
	private short state;


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public long getAddtime() {
		return addtime;
	}


	public void setAddtime(long addtime) {
		this.addtime = addtime;
	}


	public short getState() {
		return state;
	}


	public void setState(short state) {
		this.state = state;
	}
	
	
	
	


	
}
