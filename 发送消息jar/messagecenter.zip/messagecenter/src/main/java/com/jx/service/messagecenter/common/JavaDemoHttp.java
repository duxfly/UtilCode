package com.jx.service.messagecenter.common;


import java.io.UnsupportedEncodingException;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.lang.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import com.jx.service.messagecenter.util.Constant;



public class JavaDemoHttp {
	public static String sendMsg(String phone,String content)throws UnsupportedEncodingException{
		if(StringUtils.equalsIgnoreCase(Constant.serviceMode, Constant.SERVICE_MODE_TEST)){
			return null;
		}
		String strReg = "101100-WEB-HUAX-622264";   //ע��ţ��ɻ�����ͨ�ṩ��
	    String strPwd = "PBJRMRBH";                 //���루�ɻ�����ͨ�ṩ��
	    String strSourceAdd = "";                   //��ͨ���ţ���Ϊ�գ�Ԥ������һ��Ϊ�գ�
	    String strPhone = phone;//�ֻ���룬����ֻ���ð�Ƕ��ŷֿ������1000��
	    String strContent = HttpSend.paraTo16(content);       //��������
	    
	    //���²���Ϊ������URL,�Լ������������Ĳ������޸�
	    String strSmsUrl = "http://www.stongnet.com/sdkhttp/sendsms.aspx";
	    String strSmsParam = "reg=" + strReg + "&pwd=" + strPwd + "&sourceadd=" + strSourceAdd + "&phone=" + strPhone + "&content=" + strContent;;
	    
	    String strRes  = new String();
	    
	    strRes = HttpSend.postSend(strSmsUrl, strSmsParam);
	    return strRes;
	}
	public static int sendmsg1(String phone,String content) throws UnsupportedEncodingException{
		//����Ϊ����Ĳ������ʱ���޸�,��������תΪ16�����ٷ���
		String strReg = "101100-WEB-HUAX-622264";   //ע��ţ��ɻ�����ͨ�ṩ��
        String strPwd = "PBJRMRBH";                 //���루�ɻ�����ͨ�ṩ��
        String strSourceAdd = "";                   //��ͨ���ţ���Ϊ�գ�Ԥ������һ��Ϊ�գ�
        String strPhone = phone;//�ֻ���룬����ֻ���ð�Ƕ��ŷֿ������1000��
        String strContent = HttpSend.paraTo16(content);       //��������
        
        //���²���Ϊ������URL,�Լ������������Ĳ������޸�
        String strSmsUrl = "http://www.stongnet.com/sdkhttp/sendsms.aspx";
        String strSmsParam = "reg=" + strReg + "&pwd=" + strPwd + "&sourceadd=" + strSourceAdd + "&phone=" + strPhone + "&content=" + strContent;;
        
        String strRes  = new String();
        
        strRes = HttpSend.postSend(strSmsUrl, strSmsParam);
        
        System.out.println(strRes);
        int r = -1;
        String[] arr = strRes.split("&");
        if(arr.length > 1 && arr[0].equals("result=0")){
        	strRes = "ok";
        	r = 0;
        }else{
        	strRes = "fail";
        }
        return r;
        
	}
	
	public static int sendmsg(String phone,String content) throws UnsupportedEncodingException{
		if(StringUtils.equalsIgnoreCase(Constant.serviceMode, Constant.SERVICE_MODE_TEST)){
			return -1;
		}
		String Url = "http://121.199.16.178/webservice/sms.php?method=Submit";
		HttpClient client = new HttpClient(); 
		PostMethod method = new PostMethod(Url); 
		//client.getParams().setContentCharset("GBK");		
		client.getParams().setContentCharset("UTF-8");
		method.setRequestHeader("ContentType","application/x-www-form-urlencoded;charset=UTF-8");

		NameValuePair[] data = {//提交短信
			    new NameValuePair("account", "cf_xiaoweilz"), 
			    new NameValuePair("password", "xiaoweiLvzheng"), //密码可以使用明文密码或使用32位MD5加密
			    //new NameValuePair("password", util.StringUtil.MD5Encode("密码")),
			    new NameValuePair("mobile", phone), 
			    new NameValuePair("content", content),
		};
		method.setRequestBody(data);
		String code = "0";
		try {
			client.executeMethod(method);	
			String SubmitResult =method.getResponseBodyAsString();
			Document doc = DocumentHelper.parseText(SubmitResult); 
			Element root = doc.getRootElement();
			code = root.elementText("code");	
			String msg = root.elementText("msg");	
//			String smsid = root.elementText("smsid");	
			System.out.println(code+msg);
//			 if("2".equals(code)){
//				System.out.println("短信提交成功");
//			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
        
        int r = -1;
        if("2".equals(code)){
        	r = 0;
        }
        return r;
        
	}
	
	public static void main(String[] args){
		
//		Random r = new Random();
//		int code = (r.nextInt(8)+1)*1000+r.nextInt(9)*100+r.nextInt(9)*10+r.nextInt(9);
//		System.out.println(code);
		int str = -1;
		try {
			String mobiles = "13718659811,15010975647,18310191615,13501100073,13522971005,15901283459,15116933305,13661344189,18810540056,15101120984,13801351497,15801476696";
			//String mobile="18630342782";
			String mobile="13718659811";
			//String content="您好，小微已分派专业法律顾问（张国明，13718659811）为您服务，15分钟内会致电给您，请您接听。关注公众号“小微律政”更便捷享受我们的贴心服务！";
			String content= "您的验证码是：111111(15分钟有效)。";
			//String content="您好，小微已分派专业法律顾问（威力：13998987678）为您服务，15分钟内会致电给您，请您接听。关注公众号“小微律政”更便捷享受我们的贴心服务！";
			System.out.println(content.length());
			str = sendmsg(mobile,content);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		System.out.println(str);
	}
}
