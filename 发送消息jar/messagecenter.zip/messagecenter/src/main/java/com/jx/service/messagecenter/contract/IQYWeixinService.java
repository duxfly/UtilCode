package com.jx.service.messagecenter.contract;

import com.jx.spat.gaea.server.contract.annotation.OperationContract;
import com.jx.spat.gaea.server.contract.annotation.ServiceContract;

@ServiceContract
public interface IQYWeixinService {

	@OperationContract
	public String getWeixinToken(String appid,String secrect)throws Exception;
	@OperationContract
	public String sendMessage(String request,String msg)throws Exception;
}
