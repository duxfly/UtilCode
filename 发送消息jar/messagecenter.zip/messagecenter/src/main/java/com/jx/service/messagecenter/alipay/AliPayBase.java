package com.jx.service.messagecenter.alipay;

import java.io.IOException;

import sun.misc.BASE64Decoder;

import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.net.ssl.HttpsURLConnection;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

public class AliPayBase {

	private final static String apliayurl = "https://mapi.alipay.com/gateway.do";
	private final static String privatekey = "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBAOip5d8QBlHio8QD"+"\r"+
"e82b2xEAZYiAxpjP8dsjrVkP7Ys+2EAG2h5kS3SayqVV7j7BwbMdraPSeIZat0TD"+"\r"+
"w9sIeAVwipmy1LFJDSHJQyijZQWRjflIl5+Ytv2684ptEXyHOVIZ/oGN3AUn8F8i"+"\r"+
"3UFBqMHAQIuxBvGhjoE2mGCw4tP5AgMBAAECgYEAudzPl6xzgAKvlKy7v/rbu+83"+"\r"+
"LR7Ch9zGdqs/lcBVoUEo+6z9nf29EX9+lynYUyXxmScCSbafNaVOdo507YsMZLXs"+"\r"+
"xNpWjP5FtlXgzAO2KRU4gEj5Rpu/yIFTFU86ye9OkGU/aOyHyNiSwc92J0hefyYa"+"\r"+
"rFViaTskdQFL4f2bEAECQQD78ta153e1hh+omYjcfgW4wxWATC38eajHuGrQVG81"+"\r"+
"WgD8KooYKR0O+sE9V2gmQOnAQCBdG/rdesIge/HYK+z5AkEA7Ger86ETGXIJtXGM"+"\r"+
"bjNiQIHKM5uv8Lky32ZlH7xGFHvFoZ5YKReKoeAekL5t15NYfa4LMbwMXIXQkE1z"+"\r"+
"pBrfAQJBANt7nVgyILLd+M5jkjqi/lEKgbyWoKkFQudZ3JNIOuj7U0hZtpt9lXbr"+"\r"+
"M1RAxNYuTnPQaWEzcsNmoZ6y2ug6u+ECQAeGTTzV9aurq49w681eKVRwTSVTYUhC"+"\r"+
"PNJLihB2h6yDPAkm5xt3ulvorFBjH0/rSrfFYGnW2HXhdIADVxj0GgECQQDLI904"+"\r"+
"UEeOSNYsKZ+d8IhMbtf2JnvzzVRiKNHqI/Q5WjlPkqxroMnIJEfFZ0YJsEa5/XH7"+"\r"+
"WDEkR36tt1g0a9aF";
	private final static String pubkey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDoqeXfEAZR4qPEA3vNm9sRAGWI"+"\r"+
"gMaYz/HbI61ZD+2LPthABtoeZEt0msqlVe4+wcGzHa2j0niGWrdEw8PbCHgFcIqZ"+"\r"+
"stSxSQ0hyUMoo2UFkY35SJefmLb9uvOKbRF8hzlSGf6BjdwFJ/BfIt1BQajBwECL"+"\r"+
"sQbxoY6BNphgsOLT+QIDAQAB";
	
	
	public static void main(String[] args){
		KeyPairGenerator keyPairGen = null;
		try {  
            keyPairGen= KeyPairGenerator.getInstance("RSA");  
        } catch (NoSuchAlgorithmException e) {  
            e.printStackTrace();  
        }  
        keyPairGen.initialize(1024, new SecureRandom());  
        KeyPair keyPair= keyPairGen.generateKeyPair();  
        
        String ordstr = "hellozhifubao";
        RSAPublicKey publicKey = null;
		try {
			publicKey = loadPublicKey(pubkey);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		byte[] btd = null;
        try {
			btd = encrypt(publicKey,ordstr.getBytes());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.println(btd.toString());
        RSAPrivateKey rk = null;
		try {
			rk = getPrivatekey();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try {
			System.out.println(new String(decrypt(rk,btd)));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/** 
     * 解密过程 
     * @param privateKey 私钥 
     * @param cipherData 密文数据 
     * @return 明文 
     * @throws Exception 解密过程中的异常信息 
     */  
    public static byte[] decrypt(RSAPrivateKey privateKey, byte[] cipherData) throws Exception{  
        if (privateKey== null){  
            throw new Exception("解密私钥为空, 请设置");  
        }  
        Cipher cipher= null;  
        try {  
            cipher= Cipher.getInstance("RSA", new BouncyCastleProvider());  
            cipher.init(Cipher.DECRYPT_MODE, privateKey);  
            byte[] output= cipher.doFinal(cipherData);  
            return output;  
        } catch (NoSuchAlgorithmException e) {  
            throw new Exception("无此解密算法");  
        } catch (NoSuchPaddingException e) {  
            e.printStackTrace();  
            return null;  
        }catch (InvalidKeyException e) {  
            throw new Exception("解密私钥非法,请检查");  
        } catch (IllegalBlockSizeException e) {  
            throw new Exception("密文长度非法");  
        } catch (BadPaddingException e) {  
            throw new Exception("密文数据已损坏");  
        }         
    }  
    public static RSAPrivateKey getPrivatekey()throws Exception{
    	try {  
            BASE64Decoder base64Decoder= new BASE64Decoder();  
            byte[] buffer= base64Decoder.decodeBuffer(privatekey);  
            PKCS8EncodedKeySpec keySpec= new PKCS8EncodedKeySpec(buffer);  
            KeyFactory keyFactory= KeyFactory.getInstance("RSA");  
            return (RSAPrivateKey) keyFactory.generatePrivate(keySpec);  
        } catch (NoSuchAlgorithmException e) {  
            throw new Exception("无此算法");  
        } catch (InvalidKeySpecException e) {  
            throw new Exception("私钥非法");  
        } catch (IOException e) {  
            throw new Exception("私钥数据内容读取错误");  
        } catch (NullPointerException e) {  
            throw new Exception("私钥数据为空");  
        }  
    }
	/** 
     * 从字符串中加载公钥 
     * @param publicKeyStr 公钥数据字符串 
     * @throws Exception 加载公钥时产生的异常 
     */  
    public static RSAPublicKey loadPublicKey(String publicKeyStr) throws Exception{  
        try {  
            BASE64Decoder base64Decoder= new BASE64Decoder();  
            byte[] buffer= base64Decoder.decodeBuffer(publicKeyStr);  
            KeyFactory keyFactory= KeyFactory.getInstance("RSA");  
            X509EncodedKeySpec keySpec= new X509EncodedKeySpec(buffer);  
           return (RSAPublicKey) keyFactory.generatePublic(keySpec);  
        } catch (NoSuchAlgorithmException e) {  
            throw new Exception("无此算法");  
        } catch (InvalidKeySpecException e) {  
            throw new Exception("公钥非法");  
        } catch (IOException e) {  
            throw new Exception("公钥数据内容读取错误");  
        } catch (NullPointerException e) {  
            throw new Exception("公钥数据为空");  
        }  
    }  
	/** 
     * 加密过程 
     * @param publicKey 公钥 
     * @param plainTextData 明文数据 
     * @return 
     * @throws Exception 加密过程中的异常信息 
     */  
    public static byte[] encrypt(RSAPublicKey publicKey, byte[] plainTextData) throws Exception{  
        if(publicKey== null){  
            throw new Exception("加密公钥为空, 请设置");  
        }  
        Cipher cipher= null;  
        try {  
            cipher= Cipher.getInstance("RSA", new BouncyCastleProvider());  
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);  
            byte[] output= cipher.doFinal(plainTextData);  
            return output;  
        } catch (NoSuchAlgorithmException e) {  
            throw new Exception("无此加密算法");  
        } catch (NoSuchPaddingException e) {  
            e.printStackTrace();  
            return null;  
        }catch (InvalidKeyException e) {  
            throw new Exception("加密公钥非法,请检查");  
        } catch (IllegalBlockSizeException e) {  
            throw new Exception("明文长度非法");  
        } catch (BadPaddingException e) {  
            throw new Exception("明文数据已损坏");  
        }  
    }  
}
