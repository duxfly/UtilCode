package com.jx.blackface.messagecenter.core.entity;

import com.bj58.sfft.utility.dao.annotation.Column;
import com.bj58.sfft.utility.dao.annotation.Id;
import com.bj58.sfft.utility.dao.annotation.Table;
import com.jx.spat.gaea.serializer.component.annotation.GaeaMember;
import com.jx.spat.gaea.serializer.component.annotation.GaeaSerializable;

@GaeaSerializable
@Table(name = "t_lvz_mail")
public class MailBFGEntity {
	@GaeaMember
	@Id(insertable = true)
	@Column(name = "mailid")
	private long mailid;
	@GaeaMember
	@Column(name = "title")
	private String title;
	@GaeaMember
	@Column(name = "msgtype")
	private int msgtype;
	@GaeaMember
	@Column(name = "addtime")
	private long addtime;
	@GaeaMember
	@Column(name = "posttime")
	private long posttime;
	@GaeaMember
	@Column(name = "readstate")
	private int readstate;
	@GaeaMember
	@Column(name = "content")
	private String content;
	@GaeaMember
	@Column(name = "reciveid")
	private long reciveid;
	@GaeaMember
	@Column(name = "poster")
	private long poster;
	public long getMailid() {
		return mailid;
	}
	public void setMailid(long mailid) {
		this.mailid = mailid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getMsgtype() {
		return msgtype;
	}
	public void setMsgtype(int msgtype) {
		this.msgtype = msgtype;
	}
	public long getPosttime() {
		return posttime;
	}
	public void setPosttime(long posttime) {
		this.posttime = posttime;
	}
	public int getReadstate() {
		return readstate;
	}
	public void setReadstate(int readstate) {
		this.readstate = readstate;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public long getReciveid() {
		return reciveid;
	}
	public void setReciveid(long reciveid) {
		this.reciveid = reciveid;
	}
	public long getPoster() {
		return poster;
	}
	public void setPoster(long poster) {
		this.poster = poster;
	}
	public long getAddtime() {
		return addtime;
	}
	public void setAddtime(long addtime) {
		this.addtime = addtime;
	}
	
	
}
