package com.jx.blackface.messagecenter.call.service;

import com.jx.service.messagecenter.components.MoblieSmsService;
import com.jx.service.messagecenter.contract.IMoblieSmsService;

public class SendCallThread implements Runnable {

	public static IMoblieSmsService  imss = new MoblieSmsService();

	
	private Class<?> clz;
	private long from;
	private long to;
	private long time;
	private long msgid;
	public SendCallThread(Class<?> clz, long from, long to, long time,long msgid) {
		this.clz = clz;
		this.from = from;
		this.to = to;
		this.time= time;
		this.msgid = msgid;
	}

	public long getMsgid() {
		return msgid;
	}

	public void setMsgid(long msgid) {
		this.msgid = msgid;
	}

	public Class<?> getClz() {
		return clz;
	}

	public void setClz(Class<?> clz) {
		this.clz = clz;
	}

	
	public long getFrom() {
		return from;
	}

	public void setFrom(long from) {
		this.from = from;
	}

	public long getTo() {
		return to;
	}

	public void setTo(long to) {
		this.to = to;
	}

	public long getTime() {
		return time;
	}

	public void setTime(long time) {
		this.time = time;
	}

	@Override
	public void run() {
		Object msgserv  = null;
		try {
			 msgserv = Class.forName(clz.getName()).newInstance();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(msgserv instanceof BaseCallService){
			BaseCallService bme = (BaseCallService)msgserv;
			bme.putcall(this.from, this.to,this.time, this.msgid);
		}

	}

}
