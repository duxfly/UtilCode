package com.jx.blackface.messagecenter.sms.service;

import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alipay.sign.MD5;
import com.jx.blackface.messagecenter.sms.entity.SmsEntity;
import com.jx.service.messagecenter.dingding.exception.OApiException;
import com.jx.service.messagecenter.entity.AuthMsgEntity;
import com.jx.service.messagecenter.util.DateUtils;

public class QingMaYunVoiceMsgMessageService extends BaseVoiceMsgMessageService {

	// 帐号sid
//	private static final String ACCOUNT_SID = "929c8a68981a4808942a58402b0ecf3b";
	private static final String ACCOUNT_SID = "d66c3ae63609429886ba520d2bb8ad8b";
	// 帐号token
//	private static final String AUTH_TOKEN = "0a9364f81c1640619fb14e89334df294";
	private static final String AUTH_TOKEN = "b0a79d202a1849f3a618cc40b76c59f8";
	// RESTURL
//	private static final String REST_URL = "https://api.qingmayun.com";
	private static final String REST_URL = "https://api.miaodiyun.com";
	// APP_ID
//	private static final String APP_ID = "de7480009d3049acaa19a721fcc59d25";
	// 版本号
	private static final String VERSION = "/20150822";
	// 模版短信地址
	private static final String SMSTEMPLATE = REST_URL + VERSION + "/call/voiceCode";

	private static final short CHANNEL = 4;

	public static void main(String[] args) {
		BaseMessageService x = new QingMaYunVoiceMsgMessageService();
		SmsEntity e = x.sendAuthCode("18810777655", "115383",0);
		System.out.println(e);
	}

	public SmsEntity sendAuthCode(String phone, String code,long sel) {
		// TODO Auto-generated method stub
		
		String timestamp = DateUtils.getFormatDateStr(new Date(), DateUtils.DATA_FORMAT_YYYYMMDDHHMMSS);
		String sig = ACCOUNT_SID + AUTH_TOKEN + timestamp;
		System.out.println(sig);
		sig = MD5.sign(sig, "", "UTF-8");
		JSONObject sms = new JSONObject();
//		sms.put("appId", APP_ID);
		sms.put("callDisplayNumber", DISPNUMBER010);
		sms.put("called", phone);
		sms.put("verifyCode", code);
		sms.put("playTimes", 2);
		JSONObject body = new JSONObject();
		body.put("voiceCode", sms);
		System.out.println(JSON.toJSONString(body));
		System.out.println(timestamp + "--" + sig);
		String url = SMSTEMPLATE + "?sig=" + sig + "&timestamp=" + timestamp;
		JSONObject ret = null;
		try {
			ret = SMSHttpHelper.httpPost(url, body);
		} catch (OApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(ret);
		if (ret.containsKey("result")) {
			JSONObject result = ret.getJSONObject("result");
			SmsEntity se = new SmsEntity();
			se.setChannel(CHANNEL);
			se.setRespCode(result.getString("respCode"));
			se.setText(code);
			if (result.containsKey("callId"))
				se.setSmsId(result.getString("callId"));
			if (result.containsKey("createDate"))
				se.setCreateDate(result.getString("createDate"));
			
			if(sel>0)saveMsg(sel, se);
			return se;
		} else {
			return null;
		}
	}
	@Override
	public void saveMsg(long se, SmsEntity see) {
		try {
			AuthMsgEntity ame = imss.getMsgEntityById(se);
			if (ame != null ) {
				ame.setMsgid(see.getSmsId());
				ame.setMsgchannel(see.getChannel());
				if("00000".equals(see.getRespCode())){
					ame.setSendstate((short)1);
				}else{
					ame.setSendstate((short)0);
				}
				ame.setRespmessage(see.getOthMsg());
				ame.setRespcode(see.getRespCode());
				if(StringUtils.isNotBlank(see.getCreateDate())){
					ame.setSendtimestamp(DateUtils.getDateFromStr(see.getCreateDate()));
				}
				imss.updateMsgEntity(ame);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public SmsEntity sendMessage(String template, String phone, String[] text, long sel) {
		// TODO Auto-generated method stub
		return null;
	}
}
