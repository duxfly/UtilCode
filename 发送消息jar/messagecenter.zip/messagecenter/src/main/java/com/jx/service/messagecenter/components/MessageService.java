package com.jx.service.messagecenter.components;

import net.sf.json.JSONObject;

import com.jx.service.messagecenter.common.JavaDemoHttp;
import com.jx.service.messagecenter.contract.IMessageService;
import com.jx.spat.gaea.server.contract.annotation.ServiceBehavior;

@ServiceBehavior
public class MessageService implements IMessageService {

	public String sendMessage(String phonenumber, String content)
			throws Exception {
		// TODO Auto-generated method stub
		String res = JavaDemoHttp.sendMsg(phonenumber, content);
		JSONObject jo = new JSONObject();
		if(res != null && !"".equalsIgnoreCase(res)){
			String[] str = res.split("&");
			if(str.length > 1){
				if(str[0].equals("result=0")){
					jo.put("res", "ok");
				}else{
					jo.put("res", "fail");
					String[] marr = str[1].split("=");
					jo.put("remsg", marr[1]);
				}
			}
		}
		return jo.toString();
	}

	public String sendActionMessage(String phonenumber, int msgcode)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
