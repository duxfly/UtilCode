package com.jx.service.messagecenter.contract;

import java.util.List;

import com.jx.service.messagecenter.entity.OrderActionEntity;
import com.jx.spat.gaea.server.contract.annotation.OperationContract;
import com.jx.spat.gaea.server.contract.annotation.ServiceContract;

@ServiceContract
public interface IActionService {
	@OperationContract
	public OrderActionEntity getActionByid(long actionid)throws Exception;
	@OperationContract
	public List<OrderActionEntity> getActionsBypage(String condition,int pageindex,int pagesize,String orderby)throws Exception;
}
