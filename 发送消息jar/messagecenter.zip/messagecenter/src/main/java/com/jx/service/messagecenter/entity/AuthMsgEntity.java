package com.jx.service.messagecenter.entity;

import java.util.Date;

import com.bj58.sfft.utility.dao.annotation.Column;
import com.bj58.sfft.utility.dao.annotation.Id;
import com.bj58.sfft.utility.dao.annotation.Table;
import com.jx.spat.gaea.serializer.component.annotation.GaeaMember;
import com.jx.spat.gaea.serializer.component.annotation.GaeaSerializable;

@GaeaSerializable
@Table(name = "t_auth_msg")
public class AuthMsgEntity {
	@GaeaMember
	@Id(insertable = true)
	@Column(name = "Id")
	private long id;
	@GaeaMember
	@Column(name = "msgtype")
	private short msgtype;
	@GaeaMember
	@Column(name = "msgchannel")
	private short msgchannel;
	@GaeaMember
	@Column(name = "phonenumber")
	private String phonenumber;
	@GaeaMember
	@Column(name = "msgtext")
	private String msgtext;
	@GaeaMember
	@Column(name = "msgid")
	private String msgid;
	@GaeaMember
	@Column(name = "sendstate")
	private short sendstate;
	@GaeaMember
	@Column(name = "backstate")
	private short backstate;
	@GaeaMember
	@Column(name = "sendtimestamp")
	private Date sendtimestamp;
	@GaeaMember
	@Column(name = "backtimestamp")
	private Date backtimestamp;
	@GaeaMember
	@Column(name = "addtime")
	private Date addtime;
	@GaeaMember
	@Column(name = "updatetime")
	private Date updatetime;
	@GaeaMember
	@Column(name = "duration")
	private long duration;
	@GaeaMember
	@Column(name = "respmessage")
	private String respmessage;
	@GaeaMember
	@Column(name = "respcode")
	private String respcode;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public short getMsgtype() {
		return msgtype;
	}
	public void setMsgtype(short msgtype) {
		this.msgtype = msgtype;
	}
	public short getMsgchannel() {
		return msgchannel;
	}
	public void setMsgchannel(short msgchannel) {
		this.msgchannel = msgchannel;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getMsgtext() {
		return msgtext;
	}
	public void setMsgtext(String msgtext) {
		this.msgtext = msgtext;
	}
	public String getMsgid() {
		return msgid;
	}
	public void setMsgid(String msgid) {
		this.msgid = msgid;
	}
	public short getSendstate() {
		return sendstate;
	}
	public void setSendstate(short sendstate) {
		this.sendstate = sendstate;
	}
	public short getBackstate() {
		return backstate;
	}
	public void setBackstate(short backstate) {
		this.backstate = backstate;
	}
	
	public Date getSendtimestamp() {
		return sendtimestamp;
	}
	public void setSendtimestamp(Date sendtimestamp) {
		this.sendtimestamp = sendtimestamp;
	}
	public Date getAddtime() {
		return addtime;
	}
	public void setAddtime(Date addtime) {
		this.addtime = addtime;
	}
	public Date getUpdatetime() {
		return updatetime;
	}
	public void setUpdatetime(Date updatetime) {
		this.updatetime = updatetime;
	}
	public long getDuration() {
		return duration;
	}
	public void setDuration(long duration) {
		this.duration = duration;
	}
	public String getRespmessage() {
		return respmessage;
	}
	public void setRespmessage(String respmessage) {
		this.respmessage = respmessage;
	}
	public Date getBacktimestamp() {
		return backtimestamp;
	}
	public void setBacktimestamp(Date backtimestamp) {
		this.backtimestamp = backtimestamp;
	}
	public String getRespcode() {
		return respcode;
	}
	public void setRespcode(String respcode) {
		this.respcode = respcode;
	}
}
