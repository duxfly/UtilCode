package com.jx.blackface.messagecenter.core.contract;

import java.util.List;

import com.jx.blackface.messagecenter.call.entity.MobileCallResult;
import com.jx.blackface.messagecenter.core.entity.CallEntity;
import com.jx.spat.gaea.server.contract.annotation.OperationContract;
import com.jx.spat.gaea.server.contract.annotation.ServiceContract;

@ServiceContract
public interface ICallService {
	@OperationContract
	public long addCallEntity(CallEntity mbe)throws Exception;
	@OperationContract
	public CallEntity loadCallEntity(long mid)throws Exception;
	@OperationContract
	public List<CallEntity> getCallListbyPage(String condition,int pageindex,int pagesize,String orderby)throws Exception;
	@OperationContract
	public int getCallCountByCondition(String condition)throws Exception;
	@OperationContract
	public void updateCall(CallEntity mbe)throws Exception;
	@OperationContract
	public CallEntity getFirstCallByUserid(long userid)throws Exception;
	@OperationContract
	public MobileCallResult putcall(Long callid) throws Exception;
	@OperationContract
	public MobileCallResult callcancel(Long callid) throws Exception;
	@OperationContract
	public List<CallEntity> getCallListByEmp(long empid,int pageindex, int pagesize)throws Exception;
}
