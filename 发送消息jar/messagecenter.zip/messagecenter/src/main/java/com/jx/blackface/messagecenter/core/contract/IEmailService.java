package com.jx.blackface.messagecenter.core.contract;

import java.util.ArrayList;
import java.util.List;

import com.jx.blackface.messagecenter.core.entity.EmailEntity;
import com.jx.spat.gaea.server.contract.annotation.OperationContract;
import com.jx.spat.gaea.server.contract.annotation.ServiceContract;

@ServiceContract
public interface IEmailService {
	@OperationContract
	public long addEmailEntity(EmailEntity mbe)throws Exception;
	@OperationContract
	public EmailEntity loadEmailEntity(long mid)throws Exception;
	@OperationContract
	public List<EmailEntity> getEmailListbyPage(String condition,int pageindex,int pagesize,String orderby)throws Exception;
	@OperationContract
	public int getEmailCountByCondition(String condition)throws Exception;
	@OperationContract
	public void updateEmail(EmailEntity mbe)throws Exception;
	@OperationContract
	public long sendmail(EmailEntity mbe) throws Exception;
	@OperationContract
	public void sendmailbylist() throws Exception;
	@OperationContract
	public long addEmailEntityBatch(EmailEntity mbe, List<String> tolist) throws Exception;
	
	
	
}
