package com.jx.service.messagecenter.memcache;

/* ========================================================
 * 北京五八信息技术有限公司
 * 日 期：2013-3-22 下午04:06:30
 * 作 者：张艳伟
 * 版 本：1.0.0
 * 类说明：
 * 缓存常量定义
 * ========================================================
 * 修订日期     修订人    描述
 * 2013-3-22   张艳伟    创建
 */
public class CacheConstant {

	/**
	 * 缓存时间配置  缓存1分钟
	 */
	public static final int MEMC_TIME_MINUTES_1 = 60;
	/**
	 * 缓存时间配置  缓存2分钟
	 */
	public static final int MEMC_TIME_MINUTES_2 = 120;
	/**
	 * 缓存时间配置  缓存3分钟
	 */
	public static final int MEMC_TIME_MINUTES_3 = 180;
	/**
	 * 缓存时间配置  缓存5分钟
	 */
	public static final int MEMC_TIME_MINUTES_5 = 300;
	/**
	 *缓存时间配置  缓存10分钟 
	 */
	public static final int MEMC_TIME_MINUTES_10 = 600;
	
	
	/**
	 *缓存时间配置  缓存15分钟 
	 */
	public static final int MEMC_TIME_MINUTES_15 = 900;
	/**
	 * 缓存时间配置  缓存30分钟
	 */
	public static final int MEMC_TIME_MINUTES_30 = 1800;
	/**
	 * 缓存时间配置  缓存60分钟
	 */
	public static final int MEMC_TIME_MINUTES_60 = 3600;
	/**
	 * 缓存时间配置  缓存1天
	 */
	public static final int MEMC_TIME_ONE_DAY = 86400;
	/**
	 * 缓存时间配置  缓存10天
	 */
	public static final int MEMC_TIME_Ten_DAY = 864000;
	
	
}
