package com.jx.service.messagecenter.contract;

import java.util.Map;

import com.jx.service.messagecenter.entity.ModuleMessageEntity;
import com.jx.service.messagecenter.entity.OrderMessageEntity;
import com.jx.service.messagecenter.entity.PayOnlineEntity;
import com.jx.spat.gaea.server.contract.annotation.OperationContract;
import com.jx.spat.gaea.server.contract.annotation.ServiceContract;



@ServiceContract
public interface IWeixinActionService {
	//public String sendModuleMessage(String openid,int msgcode,String url,SorderEntity se)throws Exception;
	@OperationContract
	public String sendModuleByome(OrderMessageEntity omg)throws Exception;
	@OperationContract
	public String getOpenidBycode(String code)throws Exception;
	@OperationContract
	public String getShortURL(String longurl)throws Exception;
	@OperationContract
	public String payWeixin(Map<String,String> parmters)throws Exception;
	@OperationContract
	public String payWxstart(PayOnlineEntity pwe)throws Exception;
	@OperationContract
	public String checkWxpay(long orderid)throws Exception;
	@OperationContract
	public String sendModuleMsge(ModuleMessageEntity mme)throws Exception;
}
