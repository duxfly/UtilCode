package com.jx.blackface.messagecenter.call.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alipay.sign.MD5;
import com.jx.blackface.messagecenter.call.entity.CallbackEntity;
import com.jx.blackface.messagecenter.core.entity.CallEntity;
import com.jx.blackface.messagecenter.sms.service.SMSHttpHelper;
import com.jx.service.messagecenter.dingding.exception.OApiException;
import com.jx.service.messagecenter.util.DateUtils;

public class RongLianCallService extends BaseCallService {

	// 帐号sid
	private static final String ACCOUNT_SID = "8a48b551512459880151386274eb3e47";
	// 帐号token
	private static final String AUTH_TOKEN = "dec80756313a4befb7225ef34fe78abb";
	// RESTURL
	private static final String REST_URL = "https://app.cloopen.com:8883";
	// APP_ID
	private static final String APP_ID = "aaf98f89512446e201513db023a04c12";

	// CHILD_ID
	private static final String CHILD_ID = "21ccd9a8c4d411e59288ac853d9f54f2";

	// CHILD_KEY
	private static final String CHILD_KEY = "064375b8a9d9196fab1a09f97b0d9c81";
	// 验证码模版
	// private static final String AUTHCODE_TEMP = "14311723";
	// 版本号
	private static final String VERSION = "/2013-12-26";
	// 模版短信地址
	private static final String CALLBACK = REST_URL + VERSION + "/SubAccounts/" + CHILD_ID + "/Calls/Callback";

	private static final String CALLCANCEL = REST_URL + VERSION + "/SubAccounts/" + CHILD_ID + "/Calls/CallCancel";
	
	private static final short CHANNEL = 6;
	private static final Base64 base64 = new Base64();

	public static void main(String[] args) {
		BaseCallService x = new RongLianCallService();
		// SmsEntity e = x.sendAuthCode("13313169156", "341278", 0);
		// SmsEntity e = x.sendMessage("19400019", "18810777655", new
		// String[]{"顺丰","400222123456"}, 0);
		CallbackEntity e = x.putcall(18810777655L, 15001063180L, 100L, 0L);
		 System.out.println(e);
	}

	@Override
	public void saveMsg(long se, CallbackEntity see) {
		try {
			CallEntity ame = imss.loadCallEntity(se);
			if (ame != null) {
				ame.setOriginalid(see.getSmsId());
				ame.setProviderid(String.valueOf(see.getChannel()));
				if ("000000".equals(see.getRespCode())) {
					ame.setCallstate((short) 1);
				} else {
					ame.setCallstate((short) 0);
				}
//				ame.setRespmessage(see.getOthMsg());
				ame.setRespcode(see.getRespCode());
//				if (StringUtils.isNotBlank(see.getCreateDate())) {
//					ame.setSendtimestamp(DateUtils.getDateFromStr(see.getCreateDate()));
//				}
				imss.updateCall(ame);
//				ScheThreadPoolUtils.getExecutorPool().schedule(new QingMaYunSmsSaveMessageService(see.getSmsId()), 150,
//						TimeUnit.SECONDS);

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public CallbackEntity putcall(long from, long to, long time, long sel) {
		System.out.println(from + "--" + to + "--" + time);
		if (sel != 0){
			try {
				CallEntity ame = imss.loadCallEntity(sel);
				if(ame == null)return null;
				if(ame.getCallstate()!=(short)0 && ame.getCallstate()!=(short)1)return null;
				from = ame.getFromnumber();
				to = ame.getTonumber();
				time = ame.getTotaltime();
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		String timestamp = DateUtils.getFormatDateStr(new Date(), DateUtils.DATA_FORMAT_YYYYMMDDHHMMSS);
		String sig = CHILD_ID + CHILD_KEY + timestamp;
		System.out.println(sig);
		sig = MD5.sign(sig, "", "UTF-8").toUpperCase();
		JSONObject call = new JSONObject();
		call.put("from", from);
		call.put("to", to);
		call.put("userData", sel);
		call.put("maxCallTime", time);
		call.put("needRecord", "1");
		System.out.println(JSON.toJSONString(call));
		System.out.println(timestamp + "--" + sig);
		String url = CALLBACK + "?sig=" + sig;

		String auth = CHILD_ID + ":" + timestamp;
		System.out.println(auth);
		auth = base64.encodeToString(auth.getBytes());
		System.out.println(auth);
		Map<String, String> header = new HashMap<String, String>();
		header.put("Authorization", auth);
		JSONObject ret = null;
		try {
			ret = SMSHttpHelper.httpPost(url, call, header);
		} catch (OApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(ret);
		if (ret.containsKey("statusCode")) {
			CallbackEntity se = new CallbackEntity();
			se.setChannel(CHANNEL);
			se.setRespCode(ret.getString("statusCode"));
			if (ret.containsKey("CallBack")) {
				JSONObject result = ret.getJSONObject("CallBack");
				if (result.containsKey("callSid"))
					se.setSmsId(result.getString("callSid"));
				if (result.containsKey("dateCreated"))
					se.setCreateDate(result.getString("dateCreated"));
			}
			if (sel != 0)
				saveMsg(sel, se);
			return se;
		} else {
			return null;
		}
	}
	public CallbackEntity callcancel(long sel) {
		System.out.println(sel);
		String callid = null;
		CallEntity ame = null;
		if (sel != 0){
			try {
				ame = imss.loadCallEntity(sel);
				if(ame == null)return null;
				if(ame.getCallstate()!=(short)1)return null;
				callid= ame.getOriginalid();
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		String timestamp = DateUtils.getFormatDateStr(new Date(), DateUtils.DATA_FORMAT_YYYYMMDDHHMMSS);
		String sig = CHILD_ID + CHILD_KEY + timestamp;
		System.out.println(sig);
		sig = MD5.sign(sig, "", "UTF-8").toUpperCase();
		JSONObject call = new JSONObject();
		call.put("callSid", callid);
		call.put("appId", APP_ID);
		call.put("type", 1);
		
		System.out.println(JSON.toJSONString(call));
		System.out.println(timestamp + "--" + sig);
		String url = CALLCANCEL + "?sig=" + sig;

		String auth = CHILD_ID + ":" + timestamp;
		System.out.println(auth);
		auth = base64.encodeToString(auth.getBytes());
		System.out.println(auth);
		Map<String, String> header = new HashMap<String, String>();
		header.put("Authorization", auth);
		JSONObject ret = null;
		try {
			ret = SMSHttpHelper.httpPost(url, call, header);
		} catch (OApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(ret);
		if (ret.containsKey("statusCode")) {
			CallbackEntity se = new CallbackEntity();
			se.setChannel(CHANNEL);
			se.setRespCode(ret.getString("statusCode"));
			
//			if("000000".equals(ret.getString("statusCode"))){
//				try {
//					ame.setCallstate((short)3);
//					imss.updateCall(ame);
//					CallEntity cc = new CallEntity();
//					cc.setUserid(ame.getUserid());
//					cc.setOrderid(ame.getOrderid());
//					cc.setFromnumber(ame.getFromnumber());
//					cc.setTonumber(ame.getTonumber());
//					cc.setTotaltime(ame.getTotaltime()-ame.getUsetime());
//					cc.setHavetimes(ame.getHavetimes());
//					
//					cc.setLastcallid(ame.getCallid());
//					cc.setCalltype((short)1);
//					Long old = imss.addCallEntity(cc);
//					System.out.println("create new callEntity: id="+old);
//				} catch (Exception e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			}
			return se;
		} else {
			return null;
		}
	}
}
