package com.jx.blackface.messagecenter.core.components;

import java.util.Date;
import java.util.List;

import com.jx.blackface.messagecenter.core.contract.ICustomerAgentService;
import com.jx.blackface.messagecenter.core.entity.CustomerAgentEntity;
import com.jx.service.messagecenter.common.IDHelper;
import com.jx.spat.gaea.server.contract.annotation.ServiceBehavior;

@ServiceBehavior
public class CustomerAgentService extends NewCommonService implements ICustomerAgentService {

	@Override
	public long addCustomerAgentEntity(CustomerAgentEntity mbe) throws Exception {
		long resid = 0;
	
//		long pid = IDHelper.getUniqueID();
		if (mbe != null&& mbe.getEmpid()!=0) {
//			mbe.setCallid(pid);
			mbe.setAddtime(new Date().getTime());
			insertObjec(mbe);
//			resid = pid;
		}
		return resid;
	}

	@Override
	public CustomerAgentEntity loadCustomerAgentEntity(long mid) throws Exception {
		CustomerAgentEntity mbe = (CustomerAgentEntity) getObjectByid(mid, CustomerAgentEntity.class);
		return mbe;
	}

	@Override
	public List<CustomerAgentEntity> getCallListbyPage(String condition, int pageindex, int pagesize, String orderby)
			throws Exception {
		return (List<CustomerAgentEntity>) getListBypage(CustomerAgentEntity.class, condition, pageindex, pagesize, orderby);
	}

	@Override
	public int getCustomerAgentCountByCondition(String condition) throws Exception {
		return getCountBycondition(CustomerAgentEntity.class, condition);
	}

	@Override
	public void updateCustomerAgent(CustomerAgentEntity mbe) throws Exception {
		if(mbe!=null)mbe.setUpdatetime(new Date().getTime());
		updateObject(mbe);
	}

	@Override
	public CustomerAgentEntity getOneIdleCustomerAgent() throws Exception {
		List<CustomerAgentEntity> l = (List<CustomerAgentEntity>) getCallListbyPage( "callstate=0", 1, 1, "updatetime");
		if(l!=null&&l.size()>0)return l.get(0);
		return null;
	}

	@Override
	public void delCustomerAgentEntity(long mbeid) throws Exception {
		deleteObjectByid(CustomerAgentEntity.class,mbeid);
	}
	
	
}
