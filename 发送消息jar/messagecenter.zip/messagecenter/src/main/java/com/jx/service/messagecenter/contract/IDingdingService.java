/**
 * 
 */

package com.jx.service.messagecenter.contract;

import com.jx.spat.gaea.server.contract.annotation.OperationContract;
import com.jx.spat.gaea.server.contract.annotation.ServiceContract;



/**
 * simple introduction
 *
 * <p>detailed comment</p>
 * @author chuxuebao 2015年12月5日
 * @see
 * @since 1.0
 */
@ServiceContract
public interface IDingdingService {

	@OperationContract
	public String getAccessToken() throws Exception;
}
