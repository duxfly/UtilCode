package com.jx.service.messagecenter.dingding;



public class Env {
	
	public static final String OAPI_HOST = "https://oapi.dingtalk.com";
	public static final String OA_BACKGROUND_URL = ""; 
	public static final String CORP_ID = "ding034efc1905471752";
	public static final String SECRET = "D5TGXBG0_4esj7FLib5FysPlw_dyJzsGi6XZmrdlgajW9YR0YjZPIJq21lKRI7lQ";
	
	public static final String SSO_Secret = "";

	
	public static String suiteTicket; 
	public static String authCode; 
	public static String suiteToken; 

	public static final String CREATE_SUITE_KEY = "suite4xxxxxxxxxxxxxxx";
	public static final String SUITE_KEY = "";
	public static final String SUITE_SECRET = "";
	public static final String TOKEN = "";
	public static final String ENCODING_AES_KEY = "";
	
}
