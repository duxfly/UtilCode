package com.jx.blackface.messagecenter.core.entity;

import java.util.Date;

import com.bj58.sfft.utility.dao.annotation.Column;
import com.bj58.sfft.utility.dao.annotation.Id;
import com.bj58.sfft.utility.dao.annotation.Table;
import com.jx.spat.gaea.serializer.component.annotation.GaeaMember;
import com.jx.spat.gaea.serializer.component.annotation.GaeaSerializable;

@GaeaSerializable
@Table(name = "t_customer_agent")
public class CustomerAgentEntity {
	@GaeaMember
	@Id(insertable = true)
	@Column(name = "empid")
	private long empid;


	@GaeaMember
	@Column(name = "callstate")
	private short callstate;
	

	@GaeaMember
	@Column(name = "starttime")
	private Date starttime;
	
	@GaeaMember
	@Column(name = "callid")
	private long callid;
	
	@GaeaMember
	@Column(name = "addtime")
	private long addtime;
	@GaeaMember
	@Column(name = "updatetime")
	private long updatetime;
	@GaeaMember
	@Column(name = "phonenumber")
	private long phonenumber;
	

	public long getEmpid() {
		return empid;
	}

	public void setEmpid(long empid) {
		this.empid = empid;
	}

	public short getCallstate() {
		return callstate;
	}

	public void setCallstate(short callstate) {
		this.callstate = callstate;
	}

	public Date getStarttime() {
		return starttime;
	}

	public void setStarttime(Date starttime) {
		this.starttime = starttime;
	}

	public long getCallid() {
		return callid;
	}

	public void setCallid(long callid) {
		this.callid = callid;
	}

	public long getAddtime() {
		return addtime;
	}

	public void setAddtime(long addtime) {
		this.addtime = addtime;
	}

	public long getUpdatetime() {
		return updatetime;
	}

	public void setUpdatetime(long updatetime) {
		this.updatetime = updatetime;
	}

	public long getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(long phonenumber) {
		this.phonenumber = phonenumber;
	}

	
	
}
