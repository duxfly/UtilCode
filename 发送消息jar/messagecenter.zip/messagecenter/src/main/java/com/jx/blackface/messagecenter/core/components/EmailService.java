package com.jx.blackface.messagecenter.core.components;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.jx.blackface.messagecenter.core.contract.IEmailListService;
import com.jx.blackface.messagecenter.core.contract.IEmailService;
import com.jx.blackface.messagecenter.core.entity.EmailEntity;
import com.jx.blackface.messagecenter.core.entity.EmailListEntity;
import com.jx.blackface.messagecenter.email.service.EmailSMTPHelper;
import com.jx.service.messagecenter.common.IDHelper;
import com.jx.spat.gaea.server.contract.annotation.ServiceBehavior;

@ServiceBehavior
public class EmailService extends NewCommonService implements IEmailService {

	private static IEmailListService el = new EmailListService();
    private static EmailSMTPHelper e = new EmailSMTPHelper();
	@Override
	public long addEmailEntity(EmailEntity mbe) throws Exception {
		long resid = 0;
		long pid = IDHelper.getUniqueID();
		if (mbe != null) {
			mbe.setId(pid);
			mbe.setAddtime(new Date().getTime());
			insertObjec(mbe);
			resid = pid;
			EmailListEntity ele = new EmailListEntity();
			ele.setId(resid);
			ele.setState((short)0);
			el.addEmailListEntity(ele);
		}
		return resid;
	}
	@Override
	public long addEmailEntityBatch(EmailEntity mbe,List<String> tolist) throws Exception {
		long resid = 0;
		if(tolist!=null && tolist.size()>0){
			for(String x:tolist){
				long pid = IDHelper.getUniqueID();
				if (mbe != null) {
					mbe.setId(pid);
					mbe.setAddtime(new Date().getTime());
					mbe.setTo(x);
					insertObjec(mbe);
					resid ++;
					EmailListEntity ele = new EmailListEntity();
					ele.setId(pid);
					ele.setState((short)0);
					el.addEmailListEntity(ele);
				}
			}
			
		}
	
		
		return resid;
	}
	@Override
	public EmailEntity loadEmailEntity(long mid) throws Exception {
		EmailEntity mbe = (EmailEntity) getObjectByid(mid, EmailEntity.class);
		return mbe;
	}

	@Override
	public List<EmailEntity> getEmailListbyPage(String condition, int pageindex, int pagesize, String orderby)
			throws Exception {
		return (List<EmailEntity>) getListBypage(EmailEntity.class, condition, pageindex, pagesize, orderby);
	}

	@Override
	public int getEmailCountByCondition(String condition) throws Exception {
		return getCountBycondition(EmailEntity.class, condition);
	}

	@Override
	public void updateEmail(EmailEntity mbe) throws Exception {
		updateObject(mbe);
	}
	@Override
	public long sendmail(EmailEntity mbe) throws Exception {
		long resid = 0;
		long pid = IDHelper.getUniqueID();
		if (mbe != null) {
			mbe.setId(pid);
			mbe.setAddtime(new Date().getTime());
			insertObjec(mbe);
			resid = pid;
		}
		
		e.sendEmail(mbe.getFrom(), mbe.getTo(), mbe.getSubject(), mbe.getContent());
		mbe.setSendstate((short)1);
		mbe.setPosttime(new Date().getTime());
		updateObject(mbe);
		return resid;
	}
	@Override
	public void sendmailbylist() throws Exception {
		List<EmailListEntity> need = el.getEmailListListbyPage("state =0 and addtime<"+new Date().getTime(),1,100,"");
		for(EmailListEntity ee:need){
			try {
				EmailEntity mbe = loadEmailEntity(ee.getId());
				e.sendEmail(mbe.getFrom(), mbe.getTo(), mbe.getSubject(), mbe.getContent());
				mbe.setSendstate((short)1);
				mbe.setPosttime(new Date().getTime());
				updateObject(mbe);
				el.deleteEmailList(ee.getId());
			} catch (Exception e) {
				ee.setState((short)2);
				el.updateEmailList(ee);
			}
		}
	}
}
