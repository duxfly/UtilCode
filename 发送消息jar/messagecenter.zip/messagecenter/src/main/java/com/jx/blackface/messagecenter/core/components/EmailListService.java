package com.jx.blackface.messagecenter.core.components;

import java.util.Date;
import java.util.List;

import com.jx.blackface.messagecenter.core.contract.IEmailListService;
import com.jx.blackface.messagecenter.core.entity.EmailListEntity;
import com.jx.spat.gaea.server.contract.annotation.ServiceBehavior;

@ServiceBehavior
public class EmailListService extends NewCommonService implements IEmailListService {


	@Override
	public long addEmailListEntity(EmailListEntity mbe) throws Exception {
		long resid = 0;
		if (mbe != null && mbe.getId()>0) {
			mbe.setAddtime(new Date().getTime());
			insertObjec(mbe);
		}
		return resid;
	}

	@Override
	public EmailListEntity loadEmailListEntity(long mid) throws Exception {
		EmailListEntity mbe = (EmailListEntity) getObjectByid(mid, EmailListEntity.class);
		return mbe;
	}

	@Override
	public List<EmailListEntity> getEmailListListbyPage(String condition, int pageindex, int pagesize, String orderby)
			throws Exception {
		return (List<EmailListEntity>) getListBypage(EmailListEntity.class, condition, pageindex, pagesize, orderby);
	}

	@Override
	public int getEmailListCountByCondition(String condition) throws Exception {
		return getCountBycondition(EmailListEntity.class, condition);
	}

	@Override
	public void updateEmailList(EmailListEntity mbe) throws Exception {
		updateObject(mbe);
	}
	@Override
	public void deleteEmailList(long mid) throws Exception {
		deleteObjectByid(EmailListEntity.class,mid);
	}
	
}
