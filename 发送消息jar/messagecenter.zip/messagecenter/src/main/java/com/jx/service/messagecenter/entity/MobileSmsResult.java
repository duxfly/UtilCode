package com.jx.service.messagecenter.entity;

import com.jx.spat.gaea.serializer.component.annotation.GaeaMember;
import com.jx.spat.gaea.serializer.component.annotation.GaeaSerializable;

@GaeaSerializable
public class MobileSmsResult {
	@GaeaMember
	protected long smsid;
	@GaeaMember
	protected int code;//2：发送成功
	@GaeaMember
	protected String msg;
	@GaeaMember
	protected boolean result;
	@GaeaMember
	protected String returnStr;
	
	public long getSmsid() {
		return smsid;
	}
	public void setSmsid(long smsid) {
		this.smsid = smsid;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public boolean isResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	public String getReturnStr() {
		return returnStr;
	}
	public void setReturnStr(String returnStr) {
		this.returnStr = returnStr;
	}

}
