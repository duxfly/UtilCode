/**
 * 
 */

package com.jx.service.messagecenter.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;



/**
 * simple introduction
 *
 * <p>detailed comment</p>
 * @author chuxuebao 2015年7月28日
 * @see
 * @since 1.0
 */

public class DateUtils {
	private static final long nd = 1000 * 24 * 60 * 60;
	
//	private static final long nh = 1000 * 60 * 60;
	
//	private static final long nm = 1000 * 60;
    
	/* 日期样式 */
	private static final String[] DATE_PATTERNS = new String[] {
		"yyyy-MM-dd HH:mm:ss", 
		"yyyy-MM-dd", 
		"HH:mm:ss", 
		"yyyyMMddHHmmss", 
		"yyyyMMdd", 
		"yyyyMM", 
		"yyyyMMddHH", 
		"yyyy", 
		"yyyy-MM-dd'T'HH:mm:ss'Z'"
	};
	
	public static final SimpleDateFormat DATETIME_FORMAT = new SimpleDateFormat(DATE_PATTERNS[0]);
	public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(DATE_PATTERNS[1]);
	public static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat(DATE_PATTERNS[2]);
	public static final SimpleDateFormat DATA_FORMAT_YYYYMMDDHHMMSS = new SimpleDateFormat(DATE_PATTERNS[3]);
	public static final SimpleDateFormat DATA_FORMAT_YYYYMMDD = new SimpleDateFormat(DATE_PATTERNS[4]);
	public static final SimpleDateFormat DATA_FORMAT_YYYYMM = new SimpleDateFormat(DATE_PATTERNS[5]);
	public static final SimpleDateFormat DATA_FORMAT_YYYYMMDDHH = new SimpleDateFormat(DATE_PATTERNS[6]);
	public static final SimpleDateFormat DATA_FORMAT_YYYY = new SimpleDateFormat(DATE_PATTERNS[7]);
	public static final SimpleDateFormat DATA_FORMAT_yyyy_mm_dd_t_hhmmss_z = new SimpleDateFormat(DATE_PATTERNS[8]);
	public static final SimpleDateFormat DATA_FORMAT_YYYY_MM_DD_HH_MM_SS = DATETIME_FORMAT;
	public static final SimpleDateFormat DATA_FORMAT_YYYY_MM_DD = DATE_FORMAT;
	
	/**
	 * 获取当前时间
	 * @return
	 */
	public static Date getCurrentDate(){
		return new Date();
	}
	
	public static String getFormatDateStr(Date date, SimpleDateFormat format) {
		return format.format(date);
	}
	
	public static long getDurationTime(Date startDate, Date endDate){
		if(startDate != null && endDate != null){
			return endDate.getTime() - startDate.getTime();
		}
		return 0L;
	}
	public static Date getDateFromStr(String dateStr){
		Date date = null;
		try {
			date = DATETIME_FORMAT.parse(dateStr);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return date;
	}
	public static Date getDateFromStrYYYYMMDDHHMMSS(String dateStr){
		Date date = null;
		try {
			date = DATA_FORMAT_YYYYMMDDHHMMSS.parse(dateStr);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return date;
	}
	public static int getDurationDay(Date startDate, Date endDate){
		long durationTime = getDurationTime(startDate, endDate);
		double day = ((double)durationTime/nd);
		return (int)Math.round(day);
	}
	
	
}
