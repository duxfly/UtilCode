package com.jx.service.messagecenter.entity;

import com.bj58.sfft.utility.dao.annotation.Column;
import com.bj58.sfft.utility.dao.annotation.Id;
import com.bj58.sfft.utility.dao.annotation.Table;
import com.jx.spat.gaea.serializer.component.annotation.GaeaMember;
import com.jx.spat.gaea.serializer.component.annotation.GaeaSerializable;

@GaeaSerializable
@Table(name = "t_actions")
public class OrderActionEntity {
	@GaeaMember
	@Id(insertable = true)
	@Column(name = "actionid")
	private int actionid;
	@GaeaMember
	@Column(name = "actionname")
	private String actionname;
	@GaeaMember
	@Column(name = "msg")
	private String msg;
	@GaeaMember
	@Column(name = "actiondesc")
	private String actiondesc;
	@GaeaMember
	@Column(name = "necode")
	private int necode;
	@GaeaMember
	@Column(name = "actionvalue")
	private String actionvalue;
	@GaeaMember
	@Column(name = "detailvalue")
	private String detailvalue;
	@GaeaMember
	@Column(name = "wxfirststr")
	private String wxfirststr;
	@GaeaMember
	@Column(name = "wxremarkstr")
	private String wxremarkstr;
	@GaeaMember
	@Column(name = "fontstr")
	private String fontstr;
	@GaeaMember
	@Column(name = "fwfitst")
	private String fwfitst;
	@GaeaMember
	@Column(name = "fwremark")
	private String fwremark;
	@GaeaMember
	@Column(name = "cwfirst")
	private String cwfirst;
	@GaeaMember
	@Column(name = "cwremark")
	private String cwremark;
	@GaeaMember
	@Column(name = "url")
	private String url;
	@GaeaMember
	@Column(name = "templatetype")
	private int templatetype;
	
	
	public int getTemplatetype() {
		return templatetype;
	}
	public void setTemplatetype(int templatetype) {
		this.templatetype = templatetype;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getFontstr() {
		return fontstr;
	}
	public void setFontstr(String fontstr) {
		this.fontstr = fontstr;
	}
	public String getFwfitst() {
		return fwfitst;
	}
	public void setFwfitst(String fwfitst) {
		this.fwfitst = fwfitst;
	}
	public String getFwremark() {
		return fwremark;
	}
	public void setFwremark(String fwremark) {
		this.fwremark = fwremark;
	}
	public String getCwfirst() {
		return cwfirst;
	}
	public void setCwfirst(String cwfirst) {
		this.cwfirst = cwfirst;
	}
	public String getCwremark() {
		return cwremark;
	}
	public void setCwremark(String cwremark) {
		this.cwremark = cwremark;
	}
	public int getActionid() {
		return actionid;
	}
	public void setActionid(int actionid) {
		this.actionid = actionid;
	}
	public String getActionname() {
		return actionname;
	}
	public void setActionname(String actionname) {
		this.actionname = actionname;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getActiondesc() {
		return actiondesc;
	}
	public void setActiondesc(String actiondesc) {
		this.actiondesc = actiondesc;
	}
	public int getNecode() {
		return necode;
	}
	public void setNecode(int necode) {
		this.necode = necode;
	}
	public String getActionvalue() {
		return actionvalue;
	}
	public void setActionvalue(String actionvalue) {
		this.actionvalue = actionvalue;
	}
	public String getDetailvalue() {
		return detailvalue;
	}
	public void setDetailvalue(String detailvalue) {
		this.detailvalue = detailvalue;
	}
	public String getWxfirststr() {
		return wxfirststr;
	}
	public void setWxfirststr(String wxfirststr) {
		this.wxfirststr = wxfirststr;
	}
	public String getWxremarkstr() {
		return wxremarkstr;
	}
	public void setWxremarkstr(String wxremarkstr) {
		this.wxremarkstr = wxremarkstr;
	}
	
	
}
