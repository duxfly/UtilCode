package com.jx.blackface.messagecenter.email.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailSMTPHelper {
	private static final String ALIDM_SMTP_HOST = "smtpdm.aliyun.com";
	// private static final int ALIDM_SMTP_PORT = 25;
	private static final Properties uniprops = new Properties();
	private static final Map<String, Authenticator> addMap = new HashMap<String, Authenticator>();
	private static final Map<String, String> nameMap = new HashMap<String, String>();
	static {
		// 配置发送邮件的环境属性
		// 表示SMTP发送邮件，需要进行身份验证
		uniprops.put("mail.smtp.auth", "true");
		uniprops.put("mail.smtp.host", ALIDM_SMTP_HOST);
		// props.put("mail.smtp.port", ALIDM_SMTP_PORT);
		// 如果使用ssl，则去掉使用25端口的配置，进行如下配置,
		uniprops.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		uniprops.put("mail.smtp.socketFactory.port", "465");
		uniprops.put("mail.smtp.port", "465");
		// 构建授权信息，用于进行SMTP进行身份验证
		Authenticator authenticator = new MyAuthenticator("account@service.lvzheng.com", "032UVe0B3SDvqFF7IAR6");
		addMap.put("account@service.lvzheng.com", authenticator);
		nameMap.put("account@service.lvzheng.com", "小微律政账号中心");
		authenticator = new MyAuthenticator("news@service.lvzheng.com", "MUqn9upOIu5SsktRBM5N");
		addMap.put("news@service.lvzheng.com", authenticator);
		nameMap.put("news@service.lvzheng.com", "小微律政消息中心");
	}

	public void sendEmail(String user, String tomail, String subject, String content) throws Exception {

		Authenticator authenticator = addMap.get(user);

		// 使用环境属性和授权信息，创建邮件会话
		Session mailSession = Session.getInstance(uniprops, authenticator);
		// 创建邮件消息
		MimeMessage message = new MimeMessage(mailSession);
		// 设置发件人
		String senduser = ((MyAuthenticator) authenticator).getUserName();
		InternetAddress form = new InternetAddress(senduser,nameMap.get(user));
		message.setFrom(form);

		// 设置收件人
		InternetAddress to = new InternetAddress(tomail);
		message.setRecipient(MimeMessage.RecipientType.TO, to);

		// 设置邮件标题
		message.setSubject(subject);
		// 设置邮件的内容体
		message.setContent(content, "text/html;charset=UTF-8");

		// 发送邮件
		Transport.send(message);
	}

	public static void main(String[] args) throws Exception {
		EmailSMTPHelper e = new EmailSMTPHelper();

		e.sendEmail("account@service.lvzheng.com", "wlll@vip.qq.com", "测试邮件4", "测试的HTML邮件4");
	}

}
