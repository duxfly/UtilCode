package com.jx.service.messagecenter.common;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import com.jx.service.messagecenter.entity.MobileSmsResult;

public class MoblieSmsUtils {
	public static String serviceUrl = "http://121.199.16.178/webservice/sms.php?method=Submit";
	
	public static MobileSmsResult sendMsg(String phone,String content){
		HttpClient client = new HttpClient(); 
		PostMethod method = new PostMethod(serviceUrl); 
		client.getParams().setContentCharset("UTF-8");
		method.setRequestHeader("ContentType","application/x-www-form-urlencoded;charset=UTF-8");
		NameValuePair[] data = {//提交短信
			    new NameValuePair("account", "cf_xiaoweilz"), 
			    new NameValuePair("password", "xiaoweiLvzheng"), 
			    new NameValuePair("mobile", phone), 
			    new NameValuePair("content", content),
		};
		method.setRequestBody(data);
		MobileSmsResult mobileSmsResult = new MobileSmsResult();
		try {
			client.executeMethod(method);	
			String SubmitResult =method.getResponseBodyAsString();
			Document doc = DocumentHelper.parseText(SubmitResult); 
			Element root = doc.getRootElement();
			String code = root.elementText("code");	
			String msg = root.elementText("msg");	
			String smsid = root.elementText("smsid");	
			mobileSmsResult.setCode(Integer.valueOf(code));
			mobileSmsResult.setMsg(msg);
			mobileSmsResult.setSmsid(Long.valueOf(smsid));
			if("2".equals(code)){
				mobileSmsResult.setResult(true);
			}else{
				mobileSmsResult.setResult(false);
				System.out.println(code+msg);
			}
		} catch (Exception e) {
			mobileSmsResult.setResult(false);
			e.printStackTrace();
		} 
        return mobileSmsResult;
        
	}
}
