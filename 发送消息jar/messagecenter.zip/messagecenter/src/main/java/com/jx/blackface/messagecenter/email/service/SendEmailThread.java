package com.jx.blackface.messagecenter.email.service;

import com.jx.blackface.messagecenter.core.components.EmailService;
import com.jx.blackface.messagecenter.core.contract.IEmailService;

public class SendEmailThread implements Runnable {

	public static IEmailService  es = new EmailService();

	public SendEmailThread() {
	}

	
	@Override
	public void run() {
		while(true){
			try {
				es.sendmailbylist();
				Thread.sleep(2000L);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

	}

}
