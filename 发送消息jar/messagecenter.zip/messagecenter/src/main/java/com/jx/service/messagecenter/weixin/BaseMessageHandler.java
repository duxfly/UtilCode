package com.jx.service.messagecenter.weixin;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;


public class BaseMessageHandler {
	String end="\r\n";
	String twoHyphens = "--"; //用于拼接
	String boundary="*****"; //用于拼接 可
	/**
	 * 发送https请求
	 * @param requesturl
	 * @param message
	 * @return
	 * @throws Exception
	 */
	public String sendMessaeg(String requesturl,String message)throws Exception{
		String retmsg;
		System.out.println("requesturl is "+requesturl+" and the message is "+message);
		StringBuffer buffer = new StringBuffer();
		//String requestUrl = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=OubBCWtLMktHejKc8fnYQJyA-COCuph91X_HLg6TdOBLkCMlaITXlFfSbnBHuCKFTiaJxwvVzVSuu9-yYCXfmg";
		TrustManager[] tm = { new MyX509TrustManager() };
		SSLContext sslContext = SSLContext.getInstance("SSL", "SunJSSE");
		sslContext.init(null, tm, new java.security.SecureRandom());
		// 从上述SSLContext对象中得到SSLSocketFactory对象
		SSLSocketFactory ssf = sslContext.getSocketFactory();
		URL url = new URL(requesturl);
		HttpsURLConnection httpUrlConn = (HttpsURLConnection) url
				.openConnection();
		httpUrlConn.setSSLSocketFactory(ssf);
		httpUrlConn.setDoOutput(true);
		httpUrlConn.setDoInput(true);
		httpUrlConn.setUseCaches(false); // 设置请求方式（GET/POST）
		httpUrlConn.setRequestMethod("POST");
//		if ("GET".equalsIgnoreCase(requestMethod))
//			httpUrlConn.connect();
		// 当有数据需要提交时
	//	if (null != outputStr) {
			OutputStream outputStream = httpUrlConn.getOutputStream();
			// 注意编码格式，防止中文乱码
			outputStream.write(message.getBytes("UTF-8"));
			outputStream.close();
			// 将返回的输入流转换成字符串
						InputStream inputStream = httpUrlConn.getInputStream();
						InputStreamReader inputStreamReader = new InputStreamReader(
								inputStream, "utf-8");
						BufferedReader bufferedReader = new BufferedReader(
								inputStreamReader);
						String str = null;
						while ((str = bufferedReader.readLine()) != null) {
							buffer.append(str);
						}
						retmsg = buffer.toString();
						bufferedReader.close();
						inputStreamReader.close();
						// 释放资源
						inputStream.close();
						inputStream = null;
						httpUrlConn.disconnect();
		//}
		System.out.println("send msg result is "+retmsg);
		
		return retmsg;   
	}
}
