package com.jx.service.messagecenter.util;

public class MathUtil {
	  public static String getMath(){
	    	String code ="";
	    	for(int i=0 ; i<6; i++){
	        	double random = Math.random()*9;
	    		code += (int)random;
	    	}
	    	return code;
	    }
}
