package com.jx.service.messagecenter.memcache;




import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bj58.spat.memcached.MemcachedClient;

/* ========================================================
 * 北京五八信息技术有限公司
 * 日 期：2013-1-17 下午02:08:22
 * 作 者：张艳伟
 * 版 本：1.0.0
 * 类说明：
 * spat缓存实现工具类
 * ========================================================
 * 修订日期     修订人    描述
 * 2013-1-17   张艳伟    创建
 */
public class SpatMemCacheProvider extends CacheProvider{

	private static final long serialVersionUID = 1L;
	private static MemcachedClient memcachedClient = null;
	private static Log log = LogFactory.getLog(SpatMemCacheProvider.class);
	static{
		try {
			if (memcachedClient == null) {
				synchronized (SpatMemCacheProvider.class) {
					memcachedClient = MemcachedClient.getInstrance(MEMCACHECONFIG);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
		}
	}
	
	@Override
	public Object get(String key){
		if(key == null){
			return null;
		}
		try {
			key = getCacheKey(key);
			//cacheCount(2, key);
			return memcachedClient.get(key);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public boolean set(String key,Object value){
		if(key == null){
			return false;
		}
		if(value == null){
			return false;
		}
		try {
			key = getCacheKey(key);
			long time = System.currentTimeMillis() + DEFAULT_TIMEOUT;
			memcachedClient.set(key, value, (int)(time/1000));
			//cacheCount(1, key);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	@Override
	public boolean set(String key,Object value,int seconds){
		if(key == null){
			return false;
		}
		if(value == null){
			return false;
		}
		try {
			key = getCacheKey(key);
			long time = System.currentTimeMillis() + seconds*1000;
			memcachedClient.set(key, value, (int)(time/1000));
			//cacheCount(1, key);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean removeone(String key) {
		if(key == null){
			return false;
		}
		try {
			key = getCacheKey(key);
			memcachedClient.delete(key);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	@Override
	public void remove(String[] keys) {
		for (String key : keys) {
			key = getCacheKey(key);
			removeone(key);
		}
	}

	
	
	@Override
	public <T> Map<String, T> gets(String[] keys) {
		try {
			if(keys != null && keys.length > 0){
				return memcachedClient.getMap(getCacheKeyArr(keys));
			}
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return null;
	}
	
	public <T> List<T> getList(String[] keys){
		try {
			if(keys != null && keys.length > 0){
				return memcachedClient.gets(getCacheKeyArr(keys));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
