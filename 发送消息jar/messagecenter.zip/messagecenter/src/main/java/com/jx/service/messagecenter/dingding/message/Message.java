package com.jx.service.messagecenter.dingding.message;


public abstract class Message {
	public abstract String type();
}
