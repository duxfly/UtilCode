package com.jx.service.messagecenter.components;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import net.sf.json.JSONObject;

import com.jx.service.messagecenter.common.JavaDemoHttp;
import com.jx.service.messagecenter.common.StringValue;
import com.jx.service.messagecenter.common.Constants;
import com.jx.service.messagecenter.contract.IActionService;
import com.jx.service.messagecenter.contract.IWeixinActionService;
import com.jx.service.messagecenter.contract.IWeixinService;
import com.jx.service.messagecenter.entity.OrderActionEntity;
import com.jx.service.messagecenter.entity.ModuleMessageEntity;
import com.jx.service.messagecenter.entity.OrderMessageEntity;
import com.jx.service.messagecenter.entity.PayOnlineEntity;
import com.jx.service.messagecenter.weixin.BaseMessageHandler;
import com.jx.spat.gaea.server.contract.annotation.ServiceBehavior;

@ServiceBehavior
public class WeixinActionzyService extends BaseMessageHandler implements IWeixinActionService {

	private static String appid = "wx186b811cce42a0d3";
	private static String apptoken = "xwlz2016zy05zf04";
	private static String paykey = "nlR892FsYAxXJPH7WHutxjdZZ6BYGkOO";
	private static String mchid = "1338778101";
	private static String sceid = "ceedfdfcdcc3b150fa6d1f8c3711a1f7";
	private static IWeixinService iws = new WeixinService();
	private static String sendurl ="https://api.weixin.qq.com"
			+ "/cgi-bin/message/template/send?access_token=ACCESS_TOKEN";
	private static IActionService ias = new ActionService();
//	private static IMoblieSms iMoblieSms = new MoblieSmsService();
	
	public String sendModuleByome(OrderMessageEntity omg) throws Exception {
		// TODO Auto-generated method stub
		JSONObject jr = new JSONObject();
		OrderActionEntity ae = ias.getActionByid(omg.getActioncode());
		if(ae == null){
			jr.put("res", "fail");
			jr.put("msg", "发送失败，没有找到相关信息实体！");
		}else{
			String openid = omg.getOpenid();
			
			
			
			if(null != openid && !"".equals(openid) && null != ae.getWxfirststr()){
				if( !"".equals(ae.getWxfirststr()) && !"".equals(ae.getWxremarkstr()) && !"".equals(ae.getWxremarkstr())){//微信消息处理
					System.out.println("user fasong xiaoxi ");
					sendModulemsg(ae,omg,0);
				}
			}else if(ae.getMsg() != null && !"".equals(ae.getMsg())){//短信消息发送
				String fansphone = omg.getWX_FANS_PHONE();
				String content = ae.getMsg();
				content = tranceConstantsTostr(content,omg);
				//iMoblieSms.sendMsg(fansphone, content);
				JavaDemoHttp.sendmsg(fansphone, content);
			}
			String fwfirst = ae.getFwfitst();
			String fwremark = ae.getFwremark();
			//法务消息处理
			if(null != fwfirst && !"".equals(fwfirst) && null != fwremark && !"".equals(fwremark)){
				System.out.println("fw fasong xiaoxi ");
				sendModulemsg(ae,omg,1);
			}
			
			String cwfirst = ae.getCwfirst();
			String cwremark = ae.getCwremark();
			//财物消息处理
			if(null != cwfirst && !"".equals(cwfirst) && null != cwremark && !"".equals(cwremark)){
				System.out.println("cw fasong xiaoxi ");
				sendModulemsg(ae,omg,2);
			}
		}
		return jr.toString();
	}
	//0,发给用户。1，发给法务。2，发给财物
	private String sendModulemsg(OrderActionEntity ae,OrderMessageEntity omg,int type)throws Exception{
		String rs = "";
		ModuleMessageEntity mme = new ModuleMessageEntity();
		String urls = tranceConstantsTostr(ae.getUrl(),omg);
		mme.setUrl(urls);
		switch(type){
			case 0:
				mme.setOpenid(omg.getOpenid());
				mme.setFirst(ae.getWxfirststr());
				mme.setRemark(ae.getWxremarkstr());
				break;
			case 1:
				mme.setFirst(ae.getFwfitst());
				mme.setRemark(ae.getFwremark());
				mme.setOpenid(omg.getEmopenid());
				break;
			case 2:
				mme.setFirst(ae.getCwfirst());
				mme.setRemark(ae.getCwremark());
				mme.setOpenid(omg.getCwopenid());
				break;
		}
		String datas = tranceActionTojson(mme,omg);
		mme.setDatas(datas);
		String tempid = Constants.order_update_state_id;
		switch(ae.getTemplatetype()){
		case 1:
			tempid = Constants.order_submit_module_id;
			break;
		case 3:
			tempid = Constants.order_cancel_module_id;
			break;
		}
		mme.setTemplateid(tempid);
		rs = sendModuleMsge(mme);
		return rs;
	}
	public String sendModuleMsge(ModuleMessageEntity mme){
		String res = "";
		JSONObject jo = new JSONObject();
		jo.put("touser", mme.getOpenid());
		jo.put("template_id", mme.getTemplateid());
		jo.put("url", mme.getUrl());
		jo.put("topcolor", mme.getTemplateid());
		jo.put("data", mme.getDatas());
		String token = "";
		try {
			token = iws.getWeixinToken(appid, sceid);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(!token.equals("")){
			String sendurl ="https://api.weixin.qq.com"
						+ "/cgi-bin/message/template/send?access_token=ACCESS_TOKEN";
			sendurl = sendurl.replace("ACCESS_TOKEN", token);
			try {
				res = sendMessaeg(sendurl,jo.toString());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("res is --------------->"+res);
		return res;
	}
	private String tranceActionTojson(ModuleMessageEntity mme,OrderMessageEntity omg)throws Exception{
		JSONObject dd = new JSONObject();
		JSONObject first = new JSONObject();
		String firststr = tranceConstantsTostr(mme.getFirst(),omg);
		first.put("value", firststr);
		dd.put("first", first);
		
		String remarkstr = tranceConstantsTostr(mme.getRemark(),omg);
		JSONObject remark = new JSONObject();
		remark.put("value", remarkstr);
		dd.put("remark", remark);
		
		JSONObject order = new JSONObject();
		order.put("value", omg.getWX_ORDERID());
		System.out.println("module message order is is "+order.toString());
		dd.put("orderID", order);
		dd.put("OrderSn", order);
		dd.put("orderName", order);
		
		if(null != omg.getOrderstatestr() && !"".equals(omg.getOrderstatestr())){
			JSONObject ostate = new JSONObject();
			ostate.put("value", omg.getOrderstatestr());
			System.out.println("module message state is is "+ostate.toString());
			dd.put("OrderStatus", ostate);	
		}
		
		
		JSONObject jm = new JSONObject();
		jm.put("value", omg.getWX_PAY_TOTALMONEY()+"元");
		dd.put("orderMoneySum", jm);
		
		return dd.toString();
	}
	/**
	private String tranceActionTojson(ActionsEntity ae,OrderMessageEntity omg)throws Exception{
		JSONObject dd = new JSONObject();
		JSONObject first = new JSONObject();
		String firststr = tranceConstantsTostr(ae.getWxfirststr(),omg);
		first.put("value", firststr);
		dd.put("first", first);
		
		String remarkstr = tranceConstantsTostr(ae.getWxremarkstr(),omg);
		JSONObject remark = new JSONObject();
		remark.put("value", remarkstr);
		dd.put("remark", remark);
		return dd.toString();
	}
	*/
	private String tranceConstantsTostr(String cons,OrderMessageEntity omg)throws Exception{
		Field[] fs = omg.getClass().getDeclaredFields();
		String str = cons;
		if(null == str || "".equals(str)){
			return str;
		}
		System.out.println("this got str is "+str);
		for(Field f : fs){
			if(str.contains(f.getName())){
				String mstr = "get"+getMethodName(f.getName());
				System.out.println("=========="+mstr);
				Method ms = omg.getClass().getMethod(mstr);
				String r =  ms.invoke(omg) == null?"":ms.invoke(omg).toString();
				str = str.replaceAll(f.getName(), r);
				System.out.println("---------====="+str);
				
			}
				
				
		}
		return str;
	}
	 private static String getMethodName(String fildeName){
		 String ret = "";
		 char c = fildeName.charAt(0);
		 if(Character.isLowerCase(c)){
			 byte[] items = fildeName.getBytes();
				items[0] = (byte)((char)items[0]-'a'+'A');
				ret = new String(items);
		 }else{
			 ret = fildeName;
		 }
		  return ret;
	}
	public static void main(String[] args){
		try {
			System.out.println(new WeixinActionzyService().checkWxpay(32288603380993l));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public String getOpenidBycode(String code) throws Exception {
		// TODO Auto-generated method stub
		if(null == code || "".equals(code))
			return "";
		String autherurl = "https://api.weixin.qq.com/sns/oauth2/access_token?appid="+appid
				+"&secret="+sceid+"&code="+code+"&grant_type=authorization_code";
		
		BaseMessageHandler mh = new BaseMessageHandler();
		String res = "";
		try {
			res = mh.sendMessaeg(autherurl, "");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String openid = "";
		if(!res.equals("")){
			JSONObject jo = JSONObject.fromObject(res);
			if(jo.containsKey("openid")){
				openid = jo.getString("openid");
			}
			System.out.println("today got openid is "+openid);
		}
		return openid;
	}
	@Override
	public String getShortURL(String longurl) throws Exception {
		// TODO Auto-generated method stub
		String res = "";
		String token = "";
		String msg = "{\"action\":\"long2short\",\"long_url\":\""+longurl+"\"}";
		try {
			token = iws.getWeixinToken(appid, sceid);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(!token.equals("")){
			String sendurl ="https://api.weixin.qq.com"
						+ "/cgi-bin/message/template/send?access_token=ACCESS_TOKEN";
			sendurl = sendurl.replace("ACCESS_TOKEN", token);
			try {
				res = sendMessaeg(sendurl,msg);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return res;
	}
	@Override
	public String payWeixin(Map<String,String> parmters) throws Exception {
		// TODO Auto-generated method stub
		String url = "https://api.mch.weixin.qq.com/pay/unifiedorder";
		String reqstr = "appid="+appid+"&attach=thisisatest&body=test&mch_id="+mchid+"&nonce_str=ibuaiVcKdpRxkhJA&notify_url=http://m.lvzheng.com/startpay/&openid=oxizHs57LlIygy9ODhHig7z9uOsw&out_trade_no="+
parmters.get("orderid")+ "&spbill_create_ip=127.0.0.1&total_fee=1&trade_type=JSAPI&key=EKGt478kaAWygmU9AcfkK2vanc8ss8Xj";
		System.out.println("before md5 regstr is "+reqstr);
		reqstr = StringValue.MD5(reqstr).toUpperCase();
		StringBuffer sb = new StringBuffer();
		sb.append("<xml>");
		sb.append("<appid>wx76ec5c98f567d0e1</appid>");
		sb.append("<attach>thisisatest</attach>");
		sb.append("<body>test</body>");
		sb.append("<mch_id>1243594202</mch_id>");
		sb.append("<nonce_str>ibuaiVcKdpRxkhJA</nonce_str>");
		sb.append("<notify_url>http://m.lvzheng.com/startpay/</notify_url>");
		sb.append("<openid>"+parmters.get("openid")+"</openid>");
		sb.append("<out_trade_no>"+parmters.get("orderid")+"</out_trade_no>");
		sb.append("<spbill_create_ip>127.0.0.1</spbill_create_ip>");
		sb.append("<total_fee>1</total_fee>");
		sb.append("<trade_type>JSAPI</trade_type>");
		sb.append("<sign>"+reqstr+"</sign>");
		sb.append("</xml>");
		
		

		return sendMessaeg(url,new String(sb.toString().getBytes(),"ISO8859-1"));
	}
	@Override
	public String payWxstart(PayOnlineEntity pwe) throws Exception {
		// TODO Auto-generated method stub
		String url = "https://api.mch.weixin.qq.com/pay/unifiedorder";
		
		if(null != pwe){
			String tradetype = pwe.getTrade_type() == null || pwe.getTrade_type().equals("")?"JSAPI":pwe.getTrade_type();
			String reqstr = "appid="+appid+"&attach="+pwe.getAttach()+"&body="+pwe.getBody()+"&mch_id="+mchid+"&nonce_str="
			+pwe.getNonstr()+"&notify_url=http://m.xiaoweilvzheng.com/wxpay/uporderpay/"+pwe.getOrderid()+"/"+pwe.getPrepayid()+"/&openid="+pwe.getOpenid()+"&out_trade_no="+pwe.getPrepayid()+
			"&spbill_create_ip="+pwe.getIpaddress()+"&total_fee="+pwe.getMoneycount()+"&trade_type="+tradetype+"&key="+paykey;
			System.out.println("before md5 regstr is "+reqstr);
			reqstr = StringValue.MD5(reqstr).toUpperCase();
			StringBuffer sb = new StringBuffer();
			sb.append("<xml>");
			sb.append("<appid>"+appid+"</appid>");
			sb.append("<attach>"+pwe.getAttach()+"</attach>");
			sb.append("<body>"+pwe.getBody()+"</body>");
			sb.append("<mch_id>"+mchid+"</mch_id>");
			sb.append("<nonce_str>"+pwe.getNonstr()+"</nonce_str>");
			sb.append("<notify_url>http://m.xiaoweilvzheng.com/wxpay/uporderpay/"+pwe.getOrderid()+"/"+pwe.getPrepayid()+"/</notify_url>");
			sb.append("<openid>"+pwe.getOpenid()+"</openid>");
			sb.append("<out_trade_no>"+pwe.getPrepayid()+"</out_trade_no>");
			sb.append("<spbill_create_ip>"+pwe.getIpaddress()+"</spbill_create_ip>");
			sb.append("<total_fee>"+pwe.getMoneycount()+"</total_fee>");
			sb.append("<trade_type>"+tradetype+"</trade_type>");
			sb.append("<sign>"+reqstr+"</sign>");
			sb.append("</xml>");
			return sendMessaeg(url,new String(sb.toString().getBytes(),"ISO8859-1"));
		}
			return null;
		
	}
	@Override
	public String checkWxpay(long orderid) throws Exception {
		// TODO Auto-generated method stub
		String url = "https://api.mch.weixin.qq.com/pay/orderquery";
		String reqstr = "appid="+appid+"&mch_id="+mchid+"&nonce_str=ibuaiVcKdpRxkhJA&out_trade_no="+orderid+"&key="+paykey;
		reqstr = StringValue.MD5(reqstr).toUpperCase();
		StringBuffer sb = new StringBuffer();
		sb.append("<xml>");
		sb.append("<appid>"+appid+"</appid>");
		sb.append("<mch_id>"+mchid+"</mch_id>");
		sb.append("<nonce_str>ibuaiVcKdpRxkhJA</nonce_str>");
		sb.append("<out_trade_no>"+orderid+"</out_trade_no>");
		sb.append("<sign>"+reqstr+"</sign>");
		sb.append("</xml>");
		return sendMessaeg(url,new String(sb.toString().getBytes(),"ISO8859-1"));
	}
	
	
}
