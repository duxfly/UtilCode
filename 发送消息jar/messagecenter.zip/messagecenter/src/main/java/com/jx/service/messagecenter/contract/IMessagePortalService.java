package com.jx.service.messagecenter.contract;

import java.util.Map;

import com.jx.spat.gaea.server.contract.annotation.OperationContract;
import com.jx.spat.gaea.server.contract.annotation.ServiceContract;
@ServiceContract
public interface IMessagePortalService {
	@OperationContract
	int sendMsgByTemplate(String templateId, String user, Map<String, String> param, int channel, boolean onlyOnline)
			throws Exception;
	@OperationContract
	String checkUser(String user, int channel) throws Exception;
	@OperationContract
	int sendMsg(String title, String content, String user, int channel, boolean onlyOnline) throws Exception;
	@OperationContract
	int sendMsgForCoustmer(String title, String content, Long userphone, int channel) throws Exception;



}
