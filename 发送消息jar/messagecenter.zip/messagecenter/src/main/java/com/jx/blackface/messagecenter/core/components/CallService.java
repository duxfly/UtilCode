package com.jx.blackface.messagecenter.core.components;

import java.util.Date;
import java.util.List;

import com.jx.blackface.messagecenter.call.entity.MobileCallResult;
import com.jx.blackface.messagecenter.call.service.CallCancelThread;
import com.jx.blackface.messagecenter.call.service.RongLianCallService;
import com.jx.blackface.messagecenter.call.service.SendCallThread;
import com.jx.blackface.messagecenter.core.contract.ICallService;
import com.jx.blackface.messagecenter.core.contract.ICustomerAgentService;
import com.jx.blackface.messagecenter.core.entity.CallEntity;
import com.jx.blackface.messagecenter.core.entity.CustomerAgentEntity;
import com.jx.service.messagecenter.common.IDHelper;
import com.jx.service.messagecenter.util.ThreadPoolUtils;
import com.jx.spat.gaea.server.contract.annotation.ServiceBehavior;

@ServiceBehavior
public class CallService extends NewCommonService implements ICallService {

	private static ICustomerAgentService ca = new CustomerAgentService();
	@Override
	public long addCallEntity(CallEntity mbe) throws Exception {
		long resid = 0;
		long pid = IDHelper.getUniqueID();
		if (mbe != null) {
			mbe.setCallid(pid);
			mbe.setAddtime(new Date().getTime());
			insertObjec(mbe);
			resid = pid;
		}
		return resid;
	}

	@Override
	public CallEntity loadCallEntity(long mid) throws Exception {
		CallEntity mbe = (CallEntity) getObjectByid(mid, CallEntity.class);
		return mbe;
	}

	@Override
	public List<CallEntity> getCallListbyPage(String condition, int pageindex, int pagesize, String orderby)
			throws Exception {
		return (List<CallEntity>) getListBypage(CallEntity.class, condition, pageindex, pagesize, orderby);
	}

	@Override
	public int getCallCountByCondition(String condition) throws Exception {
		return getCountBycondition(CallEntity.class, condition);
	}

	@Override
	public void updateCall(CallEntity mbe) throws Exception {
		if(mbe!=null)mbe.setUpdatetime(new Date().getTime());
		updateObject(mbe);
	}
	@Override
	public CallEntity getFirstCallByUserid(long userid)throws Exception {
		List<CallEntity> lce = getCallListbyPage("callstate=0 and userid="+userid,1,1,"addtime");
		if(lce!=null&&lce.size()>0){
			return lce.get(0);
		}else{
			return null;
		}
	}
	@Override
	public List<CallEntity> getCallListByEmp(long empid,int pageindex, int pagesize)throws Exception {
		List<CallEntity> lce = getCallListbyPage("customerid="+empid,pageindex,pagesize,"addtime");
		if(lce!=null&&lce.size()>0){
			return lce;
		}else{
			return null;
		}
	}
	@Override
	public MobileCallResult putcall(Long callid) throws Exception {
		
		MobileCallResult msr = new MobileCallResult();
		msr.setResult(false);
		msr.setCode(MobileCallResult.CODE_EXCEPTION);
		CallEntity mbe = (CallEntity) getObjectByid(callid, CallEntity.class);
		if(mbe!=null && mbe.getTonumber()>0){
			if(mbe.getFromnumber()==0L){
				CustomerAgentEntity  cae = ca.getOneIdleCustomerAgent();
				if(cae==null){
					msr.setCode(MobileCallResult.CODE_NOBODY);
					return msr;
				}
				mbe.setFromnumber(cae.getPhonenumber());
				mbe.setCustomerid(cae.getEmpid());
			}else{
				CustomerAgentEntity  cae = ca.loadCustomerAgentEntity(mbe.getCustomerid());
				if(cae==null||cae.getCallstate() != 0){
					cae = ca.getOneIdleCustomerAgent();
					if(cae==null){
						msr.setCode(MobileCallResult.CODE_NOBODY);
						return msr;
					}
					mbe.setFromnumber(cae.getPhonenumber());
					mbe.setCustomerid(cae.getEmpid());
				}
			}
			mbe.setCallstate((short)1);
			updateObject(mbe);
			if(mbe.getTotaltime()>0){
				ThreadPoolUtils.getExecutorPool().execute(new SendCallThread(RongLianCallService.class,mbe.getFromnumber(),mbe.getTonumber(),mbe.getTotaltime(),callid));
				msr.setCode(MobileCallResult.CODE_SUCCESS);
				msr.setResult(true);
				return msr;
			}
		}
		return msr;
	}
	@Override
	public MobileCallResult callcancel(Long callid) throws Exception {
		
		MobileCallResult msr = new MobileCallResult();
		msr.setResult(false);
		msr.setCode(MobileCallResult.CODE_EXCEPTION);
		CallEntity mbe = (CallEntity) getObjectByid(callid, CallEntity.class);
		if(mbe!=null ){
			if(mbe.getCallstate()==1){
				ThreadPoolUtils.getExecutorPool().execute(new CallCancelThread(RongLianCallService.class,callid));
				msr.setCode(MobileCallResult.CODE_SUCCESS);
				msr.setResult(true);
				return msr;
			}
		}
		return msr;
	}
}
