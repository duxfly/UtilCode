package com.jx.service.messagecenter.common;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WebSendSmsClient {
	/**
	 * 
	 * @param ����ͨ�ͻ��ӿڲ���
	 * @param sendsmsaddress
	 * @return
	 * 
	 */
	public String commandID="3";
	public String username="jixiang";
	public String password="547CDH";
    public String serviceURL = "http://124.173.70.59:8081/SmsAndMms/mt"; 
    public static String connectURL(String commString,String sendsmsaddress) {
		String rec_string = "";
		URL url = null;
		HttpURLConnection urlConn = null;
		try {
			url = new URL(sendsmsaddress);  //�����ݵķ��͵�ַ����URL
			urlConn = (HttpURLConnection) url.openConnection(); //������
			urlConn.setConnectTimeout(30000); //���ӳ�ʱ����Ϊ30��
			urlConn.setReadTimeout(30000);	//��ȡ��ʱ����30��
			urlConn.setRequestMethod("POST");	//������Ӧ��ʽΪpost
			urlConn.setDoOutput(true);
			urlConn.setDoInput(true);
			
			OutputStream out = urlConn.getOutputStream();
			out.write(commString.getBytes("UTF-8"));
			out.flush();
			out.close();
			
			BufferedReader rd = new BufferedReader(new InputStreamReader(urlConn.getInputStream(), "UTF-8"));
			StringBuffer sb = new StringBuffer();
			int ch;
			while ((ch = rd.read()) > -1) {
				sb.append((char) ch);
			}
			
			rec_string = sb.toString().trim();
			rec_string = URLDecoder.decode(rec_string, "UTF-8");
			rd.close();
		} catch (Exception e) {
			rec_string = "-107";
		} finally {
			if (urlConn != null) {
				urlConn.disconnect();
			}
		}

		return rec_string;
	}

public String sendSms(String mobile,String content) {
		String res = "";
		try {
			String commString ="Sn="+username+"&Pwd="+password+"&mobile=" + mobile + "&content="+content;
			res = connectURL(commString,serviceURL);
		} catch (Exception e) {
			return "-10000";
		}
		//���÷���ֵ  ��������ֵ
		String resultok = "";
//			//������ʽ
			Pattern pattern = Pattern.compile("<int xmlns=\"http://tempuri.org/\">(.*)</int>");
			Matcher matcher = pattern.matcher(res);
			while (matcher.find()) {
				resultok = matcher.group(1);
			}
		return resultok;
	}
public static void main(String[] args) {
	String mobile="15101120984";
	String content="您当前验证码为999999";
	WebSendSmsClient tt=new WebSendSmsClient();
	String res=tt.sendSms(mobile,content);
	System.out.println(res);
}
	
}
