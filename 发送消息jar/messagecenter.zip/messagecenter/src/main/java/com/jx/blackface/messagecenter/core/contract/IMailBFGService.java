package com.jx.blackface.messagecenter.core.contract;

import java.util.List;

import com.jx.blackface.messagecenter.core.entity.MailBFGEntity;
import com.jx.spat.gaea.server.contract.annotation.OperationContract;
import com.jx.spat.gaea.server.contract.annotation.ServiceContract;

@ServiceContract
public interface IMailBFGService {
	@OperationContract
	public long addMessageEntity(MailBFGEntity mbe)throws Exception;
	@OperationContract
	public MailBFGEntity loadMailEntity(long mid)throws Exception;
	@OperationContract
	public List<MailBFGEntity> getMailListbypage(String condition,int pageindex,int pagesize,String orderby)throws Exception;
	@OperationContract
	public int getMailcountBycondition(String condition)throws Exception;
	@OperationContract
	public void updateMail(MailBFGEntity mbe)throws Exception;
}
