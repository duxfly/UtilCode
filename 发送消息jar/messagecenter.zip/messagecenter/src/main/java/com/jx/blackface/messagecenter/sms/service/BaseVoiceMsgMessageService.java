package com.jx.blackface.messagecenter.sms.service;



public abstract class BaseVoiceMsgMessageService  extends BaseMessageService{

}
