package com.jx.blackface.messagecenter.sms.service;

import com.jx.service.messagecenter.components.MoblieSmsService;
import com.jx.service.messagecenter.contract.IMoblieSmsService;

public class SendMsgThread implements Runnable {

	public static IMoblieSmsService  imss = new MoblieSmsService();

	
	private Class<?> clz;
	private String phone;
	private String code;
	private long msgid;
	public SendMsgThread(Class<?> clz, String phone, String code,long msgid) {
		this.clz = clz;
		this.code = code;
		this.phone = phone;
		this.msgid = msgid;
	}

	public long getMsgid() {
		return msgid;
	}

	public void setMsgid(long msgid) {
		this.msgid = msgid;
	}

	public Class<?> getClz() {
		return clz;
	}

	public void setClz(Class<?> clz) {
		this.clz = clz;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Override
	public void run() {
		Object msgserv  = null;
		try {
			 msgserv = Class.forName(clz.getName()).newInstance();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(msgserv instanceof BaseMessageService){
			BaseMessageService bme = (BaseMessageService)msgserv;
			bme.sendAuthCode(this.phone, this.code, this.msgid);
		}

	}

}
