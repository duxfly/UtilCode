package com.jx.service.messagecenter.components;

import java.util.Date;

import net.sf.json.JSONObject;

import com.jx.service.messagecenter.contract.IQYWeixinService;
import com.jx.service.messagecenter.weixin.BaseMessageHandler;
import com.jx.spat.gaea.server.contract.annotation.ServiceBehavior;

@ServiceBehavior
public class QYWeixinService implements IQYWeixinService{
	private static String token = "";
	private static long timestam = 0;
	
	private static long ticketstam = 0;
	private static String ticket = "";

	public String getWeixinToken(String appid, String secrect) throws Exception {
		// TODO Auto-generated method stub
		String tokenurl = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid="
				+appid+"&corpsecret="+secrect;
		long ced = new Date().getTime();
		long cu = new Date().getTime();
		System.out.println("before token is "+token+" timestem is "+timestam);
		if(token == null || timestam == 0 || (cu - timestam > 7200*1000)){
			synchronized(token){
				gettoken(tokenurl);
			}
			
		}
//		res = token;
		System.out.println("after token is "+token+" timestem is "+timestam);
		return token;
	}

	private static String  gettoken(String tokenurl){
		String ret = "";
		System.out.println("=================>");
		try {
			
			ret = new BaseMessageHandler().sendMessaeg(tokenurl,"");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JSONObject obj = JSONObject.fromObject(ret);
		if(ret.contains("access_token")){
			token = obj.getString("access_token");
			timestam = new Date().getTime();
		}
		return ret;
	}



	@Override
	public String sendMessage(String request, String msg) throws Exception {
		// TODO Auto-generated method stub
		String ret = "";
		try {
			ret = new BaseMessageHandler().sendMessaeg(request,msg);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ret;
	}
	public static void main(String[] args){
		String ret = "";
		String msg = "{\"action\":\"long2short\",\"long_url\":\"http://www.lvzheng.com\"}";
		String request = "";
		try {
			request = "https://api.weixin.qq.com/cgi-bin/shorturl?access_token="+new QYWeixinService().getWeixinToken("wx00ea855aaf1152af", "07a6dd9789e28772f6de32a2ec057fc0");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			ret = new BaseMessageHandler().sendMessaeg(request,msg);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JSONObject jo = JSONObject.fromObject(ret);
		System.out.println(jo.getString("short_url")); 
	}

	
}
