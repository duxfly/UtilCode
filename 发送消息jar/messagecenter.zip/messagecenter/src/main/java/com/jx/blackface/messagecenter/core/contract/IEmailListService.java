package com.jx.blackface.messagecenter.core.contract;

import java.util.List;

import com.jx.blackface.messagecenter.core.entity.EmailListEntity;
import com.jx.spat.gaea.server.contract.annotation.OperationContract;
import com.jx.spat.gaea.server.contract.annotation.ServiceContract;

@ServiceContract
public interface IEmailListService {
	@OperationContract
	public long addEmailListEntity(EmailListEntity mbe)throws Exception;
	@OperationContract
	public EmailListEntity loadEmailListEntity(long mid)throws Exception;
	@OperationContract
	public List<EmailListEntity> getEmailListListbyPage(String condition,int pageindex,int pagesize,String orderby)throws Exception;
	@OperationContract
	public int getEmailListCountByCondition(String condition)throws Exception;
	@OperationContract
	public void updateEmailList(EmailListEntity mbe)throws Exception;
	
	@OperationContract
	public void deleteEmailList(long mid) throws Exception;
}
