package com.jx.blackface.messagecenter.core.entity;

import java.util.Date;

import com.bj58.sfft.utility.dao.annotation.Column;
import com.bj58.sfft.utility.dao.annotation.Id;
import com.bj58.sfft.utility.dao.annotation.Table;
import com.jx.spat.gaea.serializer.component.annotation.GaeaMember;
import com.jx.spat.gaea.serializer.component.annotation.GaeaSerializable;

@GaeaSerializable
@Table(name = "t_lvz_email")
public class EmailEntity {
	@GaeaMember
	@Id(insertable = true)
	@Column(name = "Id")
	private long id;

	@GaeaMember
	@Column(name = "addtime")
	private long addtime;

	@GaeaMember
	@Column(name = "receiveid")
	private long receiveid;

	@GaeaMember
	@Column(name = "posttime")
	private long posttime;


	@GaeaMember
	@Column(name = "sendstate")
	private short sendstate;
	
	
	@GaeaMember
	@Column(name = "from")
	private String from;
	
	
	@GaeaMember
	@Column(name = "to")
	private String to;
	
	@GaeaMember
	@Column(name = "subject")
	private String subject;
	
	@GaeaMember
	@Column(name = "content")
	private String content;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getAddtime() {
		return addtime;
	}

	public void setAddtime(long addtime) {
		this.addtime = addtime;
	}

	public long getReceiveid() {
		return receiveid;
	}

	public void setReceiveid(long receiveid) {
		this.receiveid = receiveid;
	}

	public long getPosttime() {
		return posttime;
	}

	public void setPosttime(long posttime) {
		this.posttime = posttime;
	}

	public short getSendstate() {
		return sendstate;
	}

	public void setSendstate(short sendstate) {
		this.sendstate = sendstate;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
	
	


	
}
