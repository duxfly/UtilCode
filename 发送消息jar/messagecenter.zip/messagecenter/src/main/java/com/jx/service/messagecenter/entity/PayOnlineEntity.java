package com.jx.service.messagecenter.entity;

import com.jx.spat.gaea.serializer.component.annotation.GaeaMember;
import com.jx.spat.gaea.serializer.component.annotation.GaeaSerializable;

@GaeaSerializable
public class PayOnlineEntity {
	@GaeaMember
	private long orderid;
	@GaeaMember
	private long prepayid;
	@GaeaMember
	private long userid;
	@GaeaMember
	private String openid;
	@GaeaMember
	private long moneycount;
	@GaeaMember
	private String attach;
	@GaeaMember
	private String body;
	@GaeaMember
	private String nonstr;
	@GaeaMember
	private String ipaddress;
	@GaeaMember
	private String trade_type;
	
	
	public String getTrade_type() {
		return trade_type;
	}
	public void setTrade_type(String trade_type) {
		this.trade_type = trade_type;
	}
	public long getPrepayid() {
		return prepayid;
	}
	public void setPrepayid(long prepayid) {
		this.prepayid = prepayid;
	}
	public long getOrderid() {
		return orderid;
	}
	public void setOrderid(long orderid) {
		this.orderid = orderid;
	}
	public long getUserid() {
		return userid;
	}
	public void setUserid(long userid) {
		this.userid = userid;
	}
	public String getOpenid() {
		return openid;
	}
	public void setOpenid(String openid) {
		this.openid = openid;
	}
	public long getMoneycount() {
		return moneycount;
	}
	public void setMoneycount(long moneycount) {
		this.moneycount = moneycount;
	}
	public String getAttach() {
		return attach;
	}
	public void setAttach(String attach) {
		this.attach = attach;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public String getNonstr() {
		return nonstr;
	}
	public void setNonstr(String nonstr) {
		this.nonstr = nonstr;
	}
	public String getIpaddress() {
		return ipaddress;
	}
	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}
	
	
	
}
