package com.jx.service.messagecenter.components;

import java.io.IOException;
import java.net.URLEncoder;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Map;

import net.sf.json.JSONObject;
import net.sf.json.util.JSONUtils;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.commons.lang.StringUtils;

import com.alibaba.fastjson.JSON;
import com.jx.service.messagecenter.contract.IMessagePortalService;
import com.jx.service.messagecenter.contract.IMoblieSmsService;
import com.jx.service.messagecenter.contract.IQYWeixinService;
import com.jx.service.messagecenter.dingding.auth.AuthHelper;
import com.jx.service.messagecenter.dingding.exception.OApiException;
import com.jx.service.messagecenter.dingding.message.LightAppMessageDelivery;
import com.jx.service.messagecenter.dingding.message.MessageHelper;
import com.jx.service.messagecenter.dingding.message.MessageHelper.Receipt;
import com.jx.service.messagecenter.dingding.message.OAMessage;
import com.jx.service.messagecenter.weixin.BaseMessageHandler;
import com.jx.service.messagecenter.weixin.MySSLProtocolSocketFactory;
import com.jx.spat.gaea.server.contract.annotation.ServiceBehavior;

@ServiceBehavior
public class MessagePortalService  extends BaseMessageHandler implements IMessagePortalService {
	private static final String RTX = "RTX";
	private static final String SMS = "SMS";
	private static final String SMS_BUS = "SMS_BUS";
	private static final String UNION = "UNION";
	private static final String QY = "QY";
	private static final String MAIL = "MAIL";
	private static final String DD_OA = "DingDing_OA";
	private static final String FUWU = "FUWU";
	private static final String APPID = "wx72536a44736a0504";
	private static final String SERCET = "jLdhm1A9ARN-MK8QM_c8dVWQl65G-FOOZrQlAZrTtonQUhtpuTKTPsZOGTb_wFVd";
	public static String privateStr = "MIIBUwIBADANBgkqhkiG9w0BAQEFAASCAT0wggE5AgEAAkEAlkbGh6DwgLVZXNUsr7GqkoHkkrd5z7ceV86JEygnhANj68MxwCm/vKOd+iEsvyjqgkL5O/tjvIqDQXlvGCxCxwIDAQABAkAEoJVIY9pD/FGOHDpOBqh77mf9ZIzpqnfSuFdcMaZV2ECsc6xjzGyDAXiHNvNLXje6YxOd4ksIcucDjDCgDCRBAiEA4s7TgbcrneKM2HnUe9np9imOn/VKoSm6YVK9zYN3iXcCIQCpnkmmdfzTBLct8gfehioCu0xTEKkIQF0DbfIohyllMQIgHm4zkI7b6kYQMac+7BMTwfRXb3zAs5jeqdopHx7JdgcCIEOrVLLGa6E8RmBcKOuMFwKT+rVA9k7GbtVJbczhb5BhAiB8mlQtDTPtDZ0xO7+umfUsm7nsUDDuYNiryNz1cwu8lA==";
	public static byte[] privateKey = Base64.decodeBase64(privateStr);

	private IQYWeixinService iwe = new QYWeixinService();
	
	private IMoblieSmsService ims = new MoblieSmsService();
	
	/**
	 *  channel 0111111 最后一位sms,倒数第二位邮件,倒数第三位rtx,倒数第4位企业号,倒数第5位服务号，倒数第六位系统后台，倒数第7位钉钉OA消息
	 */
	@Override
	public int sendMsg(String title, String content, String user, int channel, boolean onlyOnline)
			throws Exception {
		int ret = 0;
		if(checkChannel(channel,SMS)){
			ret++;
		}
		if(checkChannel(channel,QY)){
			if(sendMsgQY(user,title,content)!=null)
			ret++;	
		}
		if(checkChannel(channel,RTX)){
			if(sendmsgRTX(user,title,content)!=null)
			ret++;
		}
		if(checkChannel(channel,UNION)){
			ret++;
		}
		if(checkChannel(channel,FUWU)){
			ret++;
		}
		if(checkChannel(channel,MAIL)){
			ret++;
		}
		if(checkChannel(channel,DD_OA)){
			if(sendmsgDdOa(user,title,content))
				ret++;
		}
		
		return ret;
	}
	@Override
	public int sendMsgForCoustmer(String title, String content, Long userphone, int channel)
			throws Exception {
		int ret = 0;
		if(checkChannel(channel,SMS)){
			if(JSONUtils.mayBeJSON(content)){
				JSONObject fromObject = JSONObject.fromObject(content);
				ims.sendMsg(userphone + "", fromObject.getString("template"), StringUtils.split(fromObject.getString("content"), ";") );
			}
			ret++;
		}
		if(checkChannel(channel,SMS_BUS)){
			ims.sendBusinessMsg(userphone + "", content);
			ret++;
		}
		if(checkChannel(channel,FUWU)){
			ret++;
		}
		if(checkChannel(channel,MAIL)){
			ret++;
		}
		return ret;
	}
	@Override
	public int sendMsgByTemplate(String templateId, String user, Map<String, String> param, int channel,
			boolean onlyOnline) throws Exception {
		int ret = 0;
		return ret;
	}
	@Override
	public String checkUser(String user, int channel)
			throws Exception {

		return "";
	}
	//channel 0111111 最后一位sms,倒数第二位邮件,倒数第三位rtx,倒数第4位企业号,倒数第5位服务号，倒数第六位系统后台
	private boolean checkChannel(int channel,String chan){
		if(channel==0)return true;
		if(SMS.equals(chan)){
			if((channel & 1) == 1){
				return true;
			}
		}else if(QY.equals(chan)){
			if((channel>>3 & 1) == 1){
				return true;
			}
		}else if(RTX.equals(chan)){
			if((channel>>2 & 1) == 1){
				return true;
			}
		}else if(UNION.equals(chan)){
			if((channel>>5 & 1) == 1){
				return true;
			}
		} else if(MAIL.equals(chan)){
			if((channel>>1 & 1) == 1){
				return true;
			}
		} else if(FUWU.equals(chan)){
			if((channel>>4 & 1) == 1){
				return true;
			}
		}  else if(DD_OA.equals(chan)){
			if((channel>>6 & 1) == 1){
				return true;
			}
		}  else if(SMS_BUS.equals(chan)){
			if((channel>>7 & 1) == 1){
				return true;
			}
		}
		
		return false;
	}
	
	private boolean sendmsgDdOa(String user,String agentId,String content){
		// 获取access token
		String accessToken = null;
		try {
			accessToken = AuthHelper.getAccessToken();
		} catch (OApiException e) {
			e.printStackTrace();
		}
		if(StringUtils.isBlank(accessToken)){
			System.out.println("error: getAccessToken failed. user = " + user);
			return false;
		}
		//创建oa消息
		OAMessage oaMessage = JSON.parseObject(content, OAMessage.class);
		LightAppMessageDelivery lightAppMessageDelivery = new LightAppMessageDelivery(user, "", agentId);
		lightAppMessageDelivery.withMessage(oaMessage);
		Receipt send = null;
		try {
			send = MessageHelper.send(accessToken, lightAppMessageDelivery);
		} catch (OApiException e) {
			e.printStackTrace();
		}
		if(send != null){
			return true;
		}
		System.out.println("error: sendOaMessage failed. user = " + user);
		return false;
	}
	
	private String sendmsgRTX(String user,String title,String cont) {
		// 拼接post内容
		try {
			String ztype="1";
			String str = "appkey=C6Et6Mu0yJ5h&cont="
					+ URLEncoder.encode(cont, "UTF-8") + "&title="
					+ URLEncoder.encode(title, "UTF-8") + "&user="+user+"&ztype="+ztype;
			String strForSign = "appkeyC6Et6Mu0yJ5hcont"+cont+"title"+title+"user"+user+"ztype"+ztype;;
			// 生成签名
			byte[] sign = sign(strForSign.getBytes(), privateKey);

			String signStr = Base64.encodeBase64String(sign);
			// 拼接最终内容,并转码
			String postStr = str + "&sign=" + URLEncoder.encode(signStr, "UTF-8");

			String url = null;
			String par = "/ov1/";
			url = "rtx.lvzheng.com";
			
			return gethttp(url,par, postStr,false);
		} catch (Exception e) {
			return null;
		} 
	}
	public String sendMsgQY(String user,String title,String cont){
		String res = null;
		JSONObject text2 = new JSONObject();
		text2.put("content", cont);
		JSONObject send2 = new JSONObject();
		send2.put("touser", user);
		send2.put("agentid", "7");
		send2.put("msgtype", "text");
		send2.put("safe", "0");
		send2.put("text", text2);
		String token = "";
		try {
			token = iwe.getWeixinToken(APPID, SERCET);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(!token.equals("")){
			String sendurl ="https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=ACCESS_TOKEN";
			sendurl = sendurl.replace("ACCESS_TOKEN", token);
			try {
				res = sendMessaeg(sendurl,send2.toString());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("res is --------------->"+res);
		return res;
	}
	public static String gethttp(String url, String par, String postStr, boolean https) throws HttpException, IOException {
		HttpClient client = new HttpClient();
		PostMethod post =null;
		if(https){
			String urlhttps = "https://"+url+par;  
			Protocol myhttps = new Protocol("https", new MySSLProtocolSocketFactory(), 443);   
			Protocol.registerProtocol("https", myhttps);   
			post = new PostMethod(urlhttps);  
		}else{
			client.getHostConfiguration().setHost(url, 18080, "http");
			post = new PostMethod(par);
		}
		RequestEntity s = new StringRequestEntity(postStr, "application/json",           "UTF-8");  
		post.setRequestEntity(s);
		client.executeMethod(post); // 打印服务器返回的状态
		String response = new String(post.getResponseBodyAsString().getBytes("UTF-8"));
		post.releaseConnection();
		return response;
	}
	public static final String KEY_ALGORITHM = "RSA";

	public static final String SIGNATURE_ALGORITHM = "MD5withRSA";
	/**
	 * 签名
	 * 
	 * @param data待签名数据
	 * @param privateKey
	 *            密钥
	 * @return byte[] 数字签名
	 * */
	public static byte[] sign(byte[] data, byte[] privateKey) throws Exception {

		// 取得私钥
		PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(privateKey);
		KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
		// 生成私钥
		PrivateKey priKey = keyFactory.generatePrivate(pkcs8KeySpec);
		// 实例化Signature
		Signature signature = Signature.getInstance(SIGNATURE_ALGORITHM);
		// 初始化Signature
		signature.initSign(priKey);
		// 更新
		signature.update(data);
		return signature.sign();
	}
	public static void main(String[] args) throws Exception {
		MessagePortalService mp = new MessagePortalService();
		mp.sendMsg("测试", "这是一条发自messageCenter的测试消息", "chuxuebao", 0, true);
	}
}
