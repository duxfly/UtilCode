package com.jx.service.messagecenter.components;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;

import net.sf.json.JSONObject;

import com.jx.service.messagecenter.contract.IWeixinService;
import com.jx.service.messagecenter.weixin.BaseMessageHandler;
import com.jx.spat.gaea.server.contract.annotation.ServiceBehavior;

@ServiceBehavior
public class WeixinService implements IWeixinService{
	private static String token = "";
	private static long timestam = 0;
	
	private static long ticketstam = 0;
	private static String ticket = "";

	public String getWeixinToken(String appid, String secrect) throws Exception {
		// TODO Auto-generated method stub
		String tokenurl = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid="
				+appid+"&secret="+secrect;
		long ced = new Date().getTime();
		long cu = new Date().getTime();
		System.out.println("before token is "+token+" timestem is "+timestam);
		if(token == null || timestam == 0 || (cu - timestam > 7200*1000)){
			synchronized(token){
				gettoken(tokenurl);
			}
			
		}
//		res = token;
		System.out.println("after token is "+token+" timestem is "+timestam);
		return token;
	}

	private static String  gettoken(String tokenurl){
		String ret = "";
		System.out.println("=================>");
		try {
			
			ret = new BaseMessageHandler().sendMessaeg(tokenurl,"");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JSONObject obj = JSONObject.fromObject(ret);
		if(ret.contains("access_token")){
			token = obj.getString("access_token");
			timestam = new Date().getTime();
		}
		return ret;
	}

	public String makeWeixinQuer(String appid, String secrect,int sceneid) throws Exception {
		// TODO Auto-generated method stub
		String pic = "";
		String date = "{\"expire_seconds\": 1800, \"action_name\": \"QR_SCENE\", \"action_info\":"
				+ " {\"scene\": {\"scene_id\": \""+sceneid+"\"}}}";
		
		System.out.println("======>"+date);
		BaseMessageHandler mr = new BaseMessageHandler();
		String ticketjoson = "";
		try {
			String token = getWeixinToken(appid,secrect);
			ticketjoson = mr.sendMessaeg("https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=TOKEN".replace("TOKEN", token), date);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		JSONObject jo = JSONObject.fromObject(ticketjoson);
		System.out.println("this big date is "+ticketjoson);
		String ticket = "";
		try {
			ticket = URLEncoder.encode(jo.getString("ticket"),"utf-8");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pic = "https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=TICKET".replace("TICKET", ticket);
		return pic;
	}

	@Override
	public String sendMessage(String request, String msg) throws Exception {
		// TODO Auto-generated method stub
		String ret = "";
		try {
			ret = new BaseMessageHandler().sendMessaeg(request,msg);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ret;
	}
	public static void main(String[] args){
		String ret = "";
		String msg = "{\"action\":\"long2short\",\"long_url\":\"http://www.lvzheng.com\"}";
		String request = "";
		try {
			request = "https://api.weixin.qq.com/cgi-bin/shorturl?access_token="+new WeixinService().getWeixinToken("wx00ea855aaf1152af", "07a6dd9789e28772f6de32a2ec057fc0");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			ret = new BaseMessageHandler().sendMessaeg(request,msg);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JSONObject jo = JSONObject.fromObject(ret);
		System.out.println(jo.getString("short_url")); 
	}

	@Override
	public String getWeixinJSToken(String appid, String secrect)
			throws Exception {
		// TODO Auto-generated method stub
		String jstoken = "";
		String token = getWeixinToken(appid,secrect);
		
		long ced = new Date().getTime();
		if(ticket.equals("") || ticketstam == 0 || (ced - ticketstam) > 7000*1000){
			synchronized(ticket){
				jstoken = newticket(token);
			}
		}
		return jstoken;
	}
	public static String newticket(String token)throws Exception{
		String jstickeurl = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=WX_URL&type=jsapi";
		String requestUrl = jstickeurl.replaceAll("WX_URL", token);
		String astokenrs = new BaseMessageHandler().sendMessaeg(requestUrl, "");
		JSONObject jo = JSONObject.fromObject(astokenrs);
		if(jo.get("ticket") != null ){//成功
			ticket = (String) jo.get("ticket");
		}else{
			
		}
		return ticket;
	}
}
