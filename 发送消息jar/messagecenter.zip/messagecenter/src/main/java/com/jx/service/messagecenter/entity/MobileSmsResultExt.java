package com.jx.service.messagecenter.entity;

import com.jx.spat.gaea.serializer.component.annotation.GaeaSerializable;

@GaeaSerializable
public class MobileSmsResultExt extends MobileSmsResult{
	
	//超出最大条数
	public static final int CODE_OUTOFMAX = -8;
	//发送成功
	public static final int CODE_SUCCESS = 1;
	//语音发送成功
	public static final int CODE_SUCCESS_VOICE = 2;
	
	public static final int CODE_TEST = 3;
	//发送失败
	public static final int CODE_FAIL = -1;
	//发送异常
	public static final int CODE_EXCEPTION = -2;
	
	private String msgid;

	public String getMsgid() {
		return msgid;
	}

	public void setMsgid(String msgid) {
		this.msgid = msgid;
	}
	public String toString() {
		return "smsid:" + this.smsid + "    code:" + this.code + "    msg:" + this.msg + "    result:"
				+ this.result + "    returnStr:" + this.returnStr + "    msgid:" + this.msgid;
	}
	
}
