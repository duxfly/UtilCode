package com.jx.service.messagecenter.entity;

import com.jx.spat.gaea.serializer.component.annotation.GaeaMember;
import com.jx.spat.gaea.serializer.component.annotation.GaeaSerializable;

@GaeaSerializable
public class ModuleMessageEntity {

	@GaeaMember
	private String openid;
	@GaeaMember
	private String msgtitle;
	@GaeaMember
	private String first;
	@GaeaMember
	private String remark;
	@GaeaMember
	private String templateid;
	@GaeaMember
	private String url;
	@GaeaMember
	private String topcolor;
	@GaeaMember
	private int moduletype;
	@GaeaMember
	private String datas;
	
	public String getOpenid() {
		return openid;
	}
	public void setOpenid(String openid) {
		this.openid = openid;
	}
	public String getFirst() {
		return first;
	}
	public void setFirst(String first) {
		this.first = first;
	}
	public String getMsgtitle() {
		return msgtitle;
	}
	public void setMsgtitle(String msgtitle) {
		this.msgtitle = msgtitle;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getTemplateid() {
		return templateid;
	}
	public void setTemplateid(String templateid) {
		this.templateid = templateid;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getTopcolor() {
		return topcolor;
	}
	public void setTopcolor(String topcolor) {
		this.topcolor = topcolor;
	}
	public int getModuletype() {
		return moduletype;
	}
	public void setModuletype(int moduletype) {
		this.moduletype = moduletype;
	}
	public String getDatas() {
		return datas;
	}
	public void setDatas(String datas) {
		this.datas = datas;
	}
	
	
}
