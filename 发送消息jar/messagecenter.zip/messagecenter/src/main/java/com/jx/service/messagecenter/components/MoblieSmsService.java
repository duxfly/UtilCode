package com.jx.service.messagecenter.components;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

import com.jx.blackface.messagecenter.sms.service.QingMaYunBusinessSmsMessageService;
import com.jx.blackface.messagecenter.sms.service.QingMaYunSmsMessageService;
import com.jx.blackface.messagecenter.sms.service.QingMaYunVoiceMsgMessageService;
import com.jx.blackface.messagecenter.sms.service.SendMsgThread;
import com.jx.blackface.messagecenter.sms.service.SendNormalMsgThread;
import com.jx.blackface.messagecenter.sms.service.ShanghaiSmsMessageService;
import com.jx.blackface.messagecenter.sms.service.YunZhiXunSmsMessageService;
import com.jx.blackface.messagecenter.sms.service.YunZhiXunVoiceMsgMessageService;
import com.jx.service.messagecenter.common.IDHelper;
import com.jx.service.messagecenter.common.MoblieSmsUtils;
import com.jx.service.messagecenter.contract.IMoblieSmsService;
import com.jx.service.messagecenter.entity.AuthMsgEntity;
import com.jx.service.messagecenter.entity.MobileSmsResult;
import com.jx.service.messagecenter.entity.MobileSmsResultExt;
import com.jx.service.messagecenter.memcache.CacheConstant;
import com.jx.service.messagecenter.memcache.CacheManager;
import com.jx.service.messagecenter.util.Constant;
import com.jx.service.messagecenter.util.MathUtil;
import com.jx.service.messagecenter.util.ThreadPoolUtils;
import com.jx.spat.gaea.server.contract.annotation.ServiceBehavior;

@ServiceBehavior
public class MoblieSmsService extends CommonService implements IMoblieSmsService {
	
	public MobileSmsResult sendMsg(String phone, String msgContent) throws Exception {
		Pattern pattern = Pattern.compile("您的验证码是：(\\d{6})\\(15分钟有效\\).");
		Matcher matcher = pattern.matcher(msgContent);
		boolean b = matcher.matches();
		if (b) {
			initAuthMsg(phone, matcher.group(1));
		}
		System.out.println("************serviceMode=" + Constant.serviceMode);
		if(StringUtils.equalsIgnoreCase(Constant.serviceMode, Constant.SERVICE_MODE_WORK)){
			System.out.println("***************work");
			// 正式环境
			return MoblieSmsUtils.sendMsg(phone, msgContent);
		}
		System.out.println("***************test");
		// 测试环境
		MobileSmsResult re = new MobileSmsResult();
		re.setResult(true);
		return re;
	}
	
	
	public MobileSmsResult sendMsg(String phone, String temp,String []msgContent) throws Exception {
		StringBuffer k = new StringBuffer();
		for(String n:msgContent){
			k.append(n);
			k.append(" ");
		}
		long l = initAuthMsg(phone, k.toString());
		System.out.println("************serviceMode=" + Constant.serviceMode);
		if(StringUtils.equalsIgnoreCase(Constant.serviceMode, Constant.SERVICE_MODE_WORK)){
			System.out.println("***************work"+"----temp:"+temp);
			// 正式环境
			MobileSmsResultExt msr = new MobileSmsResultExt();
			System.out.println("***************work1"+phone);
			msr.setResult(false);
			msr.setCode(MobileSmsResultExt.CODE_EXCEPTION);
			if(StringUtils.isBlank(phone)){
				return msr;
			}
			ThreadPoolUtils.getExecutorPool().execute(new SendNormalMsgThread(QingMaYunSmsMessageService.class,temp,phone,msgContent,l));
			msr.setCode(MobileSmsResultExt.CODE_SUCCESS);
			msr.setResult(true);
			return msr;
		}
		System.out.println("***************test");
		// 测试环境
		MobileSmsResult re = new MobileSmsResult();
		re.setResult(true);
		return re;
	}
	
	public MobileSmsResult sendBusinessMsg(String phone, String text) throws Exception {
		long l = initAuthMsg(phone, text);
		System.out.println("************serviceMode=" + Constant.serviceMode);
		if(StringUtils.equalsIgnoreCase(Constant.serviceMode, Constant.SERVICE_MODE_WORK)){
			System.out.println("***************work"+"----temp:"+text);
			// 正式环境
			MobileSmsResultExt msr = new MobileSmsResultExt();
			System.out.println("***************work1"+phone);
			msr.setResult(false);
			msr.setCode(MobileSmsResultExt.CODE_EXCEPTION);
			if(StringUtils.isBlank(phone)){
				return msr;
			}
			ThreadPoolUtils.getExecutorPool().execute(new SendNormalMsgThread(QingMaYunBusinessSmsMessageService.class,null,phone,new String[]{text},l));
			msr.setCode(MobileSmsResultExt.CODE_SUCCESS);
			msr.setResult(true);
			return msr;
		}
		System.out.println("***************test");
		// 测试环境
		MobileSmsResult re = new MobileSmsResult();
		re.setResult(true);
		return re;
	}
	
	public static void main(String[] args) {
		String msgContent="您的验证码是：111111(15分钟有效)。";
		 Pattern pattern = Pattern.compile("您的验证码是：(\\d{6})\\(15分钟有效\\).");
		  Matcher matcher = pattern.matcher(msgContent);
		  boolean b= matcher.matches();
	
		if(b){
			System.out.println(matcher.group(1));
		}
	}
	public MobileSmsResultExt sendVerifyCode(String phone) throws Exception {
		return sendVerifyCodex(phone, (short) 0 );
	}
	public MobileSmsResultExt sendVerifyCodex(String phone,Short channel) throws Exception {
		MobileSmsResultExt msr = new MobileSmsResultExt();
		msr.setResult(false);
		msr.setCode(MobileSmsResultExt.CODE_EXCEPTION);
		if(StringUtils.isBlank(phone)){
			return msr;
		}
		try {
			// 短信发送计数
			String phonecount = "www-msgcount-" + phone;
			// 验证码内容
			String phonecode = "www-msgcode-" + phone;
			// 验证码错误计数
			String phonecodeerr = "www-msgcodeerr-" + phone;
			CacheManager.removeone(phonecodeerr);
			Object t = CacheManager.get(phonecount);
			Integer pcount = 0;
			
			if (t != null) {
				pcount = (Integer) t;
				System.out.println(phone+"--count:"+pcount);
				if (pcount > 11) {
					msr.setCode(MobileSmsResultExt.CODE_OUTOFMAX);
					return msr;
				}
			}
			
			Object p = CacheManager.get(phonecode);
			String pcode = null;
			if (p != null) {
				pcode = (String) p;
			}
			System.out.println(phone+"--count:"+pcount+"    code:"+pcode);
			if (StringUtils.isBlank(pcode)) {
				pcode = MathUtil.getMath();
			}
			
			Calendar gc = Calendar.getInstance();

			long now = gc.getTimeInMillis();
			gc.set(gc.get(Calendar.YEAR), gc.get(Calendar.MONTH), gc.get(Calendar.DAY_OF_MONTH), 23, 59, 59);
			long til = gc.getTimeInMillis();
			CacheManager.set(phonecount, pcount + 1, (int) (til - now) / 1000);
			CacheManager.set(phonecode, pcode, CacheConstant.MEMC_TIME_MINUTES_15);
//			SmsEntity se = null;
//			BaseMessageService ms = null;
			long l = initAuthMsg(phone,pcode);
			msr.setMsg(pcode);
			// 正式环境，发送消息
			if(StringUtils.equalsIgnoreCase(Constant.serviceMode, Constant.SERVICE_MODE_WORK)){
				System.out.println("***************work");
				if ((pcount < 2 && channel ==0)||channel == 1) {
					System.out.println("choice ShanghaiSmsMessageService");
					ThreadPoolUtils.getExecutorPool().execute(new SendMsgThread(ShanghaiSmsMessageService.class,phone,pcode,l));
					msr.setCode(MobileSmsResultExt.CODE_SUCCESS);
					msr.setResult(true);
//					ms = new ShanghaiSmsMessageService();
//					se = ms.sendAuthCode(phone, pcode);
//					if ("2".equals(se.getRespCode())) {
//						msr.setCode(MobileSmsResultExt.CODE_SUCCESS);
//						msr.setResult(true);
//						msr.setMsg(se.getText());
//						msr.setMsgid(se.getSmsId());
//						msr.setReturnStr(se.getOthMsg());
//					} else {
//						msr.setCode(MobileSmsResultExt.CODE_FAIL);
//					}
/*				} else if (((pcount % 2 == 1) && (pcount < 8) && channel ==0)||channel == 2) {
					System.out.println("choice QingMaYunSmsMessageService");
					ThreadPoolUtils.getExecutorPool().execute(new SendMsgThread(QingMaYunSmsMessageService.class,phone,pcode,l));
					msr.setCode(MobileSmsResultExt.CODE_SUCCESS);
					msr.setResult(true);*/
//					ms = new QingMaYunSmsMessageService();
//					se = ms.sendAuthCode(phone, pcode);
//					if ("00000".equals(se.getRespCode())) {
//						msr.setCode(MobileSmsResultExt.CODE_SUCCESS);
//						msr.setResult(true);
//						msr.setMsg(se.getText());
//						msr.setMsgid(se.getSmsId());
//						msr.setReturnStr(se.getOthMsg());
//					} else {
//						msr.setCode(MobileSmsResultExt.CODE_FAIL);
//					}
				} else if ((pcount < 4  && channel ==0)||channel == 3) {
					System.out.println("choice YunZhiXunSmsMessageService");
					ThreadPoolUtils.getExecutorPool().execute(new SendMsgThread(YunZhiXunSmsMessageService.class,phone,pcode,l));
					msr.setCode(MobileSmsResultExt.CODE_SUCCESS);
					msr.setResult(true);
//					ms = new YunZhiXunSmsMessageService();
//					se = ms.sendAuthCode(phone, pcode);
//					if ("000000".equals(se.getRespCode())) {
//						msr.setCode(MobileSmsResultExt.CODE_SUCCESS);
//						msr.setResult(true);
//						msr.setMsg(se.getText());
//						msr.setMsgid(se.getSmsId());
//						msr.setReturnStr(se.getOthMsg());
//					} else {
//						msr.setCode(MobileSmsResultExt.CODE_FAIL);
//					}
				} /*else if ((pcount % 2 == 1 && channel ==0)||channel == 4) {
					System.out.println("choice QingMaYunVoiceMsgMessageService");
					ThreadPoolUtils.getExecutorPool().execute(new SendMsgThread(QingMaYunVoiceMsgMessageService.class,phone,pcode,l));
					msr.setCode(MobileSmsResultExt.CODE_SUCCESS_VOICE);
					msr.setResult(true);
//					ms = new QingMaYunVoiceMsgMessageService();
//					se = ms.sendAuthCode(phone, pcode);
//					if ("00000".equals(se.getRespCode())) {
//						msr.setCode(MobileSmsResultExt.CODE_SUCCESS_VOICE);
//						msr.setResult(true);
//						msr.setMsg(se.getText());
//						msr.setMsgid(se.getSmsId());
//						msr.setReturnStr(se.getOthMsg());
//					} else {
//						msr.setCode(MobileSmsResultExt.CODE_FAIL);
//					}
				} */else if(channel ==0||channel == 5){
					System.out.println("choice YunZhiXunVoiceMsgMessageService");
					ThreadPoolUtils.getExecutorPool().execute(new SendMsgThread(YunZhiXunVoiceMsgMessageService.class,phone,pcode,l));
					msr.setCode(MobileSmsResultExt.CODE_SUCCESS_VOICE);
					msr.setResult(true);
//					ms = new YunZhiXunVoiceMsgMessageService();
//					se = ms.sendAuthCode(phone, pcode);
//					if ("000000".equals(se.getRespCode())) {
//						msr.setCode(MobileSmsResultExt.CODE_SUCCESS_VOICE);
//						msr.setResult(true);
//						msr.setMsg(se.getText());
//						msr.setMsgid(se.getSmsId());
//						msr.setReturnStr(se.getOthMsg());
//					} else {
//						msr.setCode(MobileSmsResultExt.CODE_FAIL);
//					}
				}
			}else{
				msr.setResult(true);
				msr.setCode(MobileSmsResultExt.CODE_TEST);
				System.out.println("***************test");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return msr;
	}

	public Boolean checkVerifyCode(String phone, String code) throws Exception {
		boolean r = false;

		try {
			String phonecode = "www-msgcode-" + phone;
			String phonecodeerr = "www-msgcodeerr-" + phone;
			Object p = CacheManager.get(phonecode);
			String pcode = null;
			if (p != null) {
				pcode = (String) p;
			}
			if (pcode != null && code != null && code.equals(pcode)) {

				CacheManager.removeone(phonecodeerr);
				CacheManager.removeone(phonecode);
				r = true;
			} else {
				if (pcode != null) {
					Object cerr = CacheManager.get(phonecodeerr);
					Integer ecount = 0;
					if (cerr != null) {
						ecount = (Integer) cerr;
					}
					if (ecount > 5) {
						CacheManager.removeone(phonecodeerr);
						CacheManager.removeone(phonecode);
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return r;
	}
	public long initAuthMsg(String phone,String code){
		AuthMsgEntity ame = new AuthMsgEntity();
		ame.setPhonenumber(phone);
		ame.setMsgtext(code);
		ame.setSendstate((short)-1);
		ame.setBackstate((short)-1);
		ame.setMsgtype((short)1);
		ame.setSendtimestamp(new Date());
		long re =0;
		try {
			re = addMsgEntity(ame);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return re;
	}
	public long addMsgEntity(AuthMsgEntity e) throws Exception {
		// TODO Auto-generated method stub
		long resid = 0;
		long pid = IDHelper.getUniqueID();
		if (e != null) {
			e.setId(pid);
			e.setAddtime(new Date());
			insertObjec(e);
			resid = pid;
		}
		return resid;
	}

	public void updateMsgEntity(AuthMsgEntity e) throws Exception {
		System.out.println("channel"+e.getMsgchannel());
		e.setUpdatetime(new Date());
		updateObject(e);
	}

	public AuthMsgEntity getMsgEntityById(long Followupid) throws Exception {
		return (AuthMsgEntity) getObjectByid(Followupid, AuthMsgEntity.class);
	}

	public List<AuthMsgEntity> getMsgEntity(String condition, int pageindex, int pagesize, String orderby)
			throws Exception {
		return (List<AuthMsgEntity>) getListBypage(AuthMsgEntity.class, condition, pageindex, pagesize, orderby);
	}

	@Override
	public MobileSmsResultExt sendVerifyCode(String phone, short channel) throws Exception {
		return sendVerifyCodex(phone,channel);
	}
	@Override
	public int getCount(String condition) throws Exception {
		// TODO Auto-generated method stub
		return getCountBycondition(AuthMsgEntity.class, condition);
	}


}
