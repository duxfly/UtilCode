package com.jx.blackface.messagecenter.sms.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import com.alibaba.fastjson.JSONObject;
import com.alipay.sign.MD5;
import com.jx.blackface.messagecenter.sms.entity.SmsEntity;
import com.jx.service.messagecenter.dingding.exception.OApiException;
import com.jx.service.messagecenter.entity.AuthMsgEntity;
import com.jx.service.messagecenter.util.DateUtils;

public class QingMaYunSmsMessageService extends BaseSmsMessageService {

	// 帐号sid
//	private static final String ACCOUNT_SID = "929c8a68981a4808942a58402b0ecf3b";
	private static final String ACCOUNT_SID = "d66c3ae63609429886ba520d2bb8ad8b";
	// 帐号token
//	private static final String AUTH_TOKEN = "0a9364f81c1640619fb14e89334df294";
	private static final String AUTH_TOKEN = "b0a79d202a1849f3a618cc40b76c59f8";
	// RESTURL
//	private static final String REST_URL = "https://api.qingmayun.com";
	private static final String REST_URL = "https://api.miaodiyun.com";
	// APP_ID
//	private static final String APP_ID = "de7480009d3049acaa19a721fcc59d25";
	// 验证码模版
	private static final String AUTHCODE_TEMP = "14311723";
	// 版本号
	private static final String VERSION = "/20150822";
	// 模版短信地址
	private static final String SMSTEMPLATE = REST_URL + VERSION + "/industrySMS/sendSMS";
	private static final short CHANNEL = 2;

	@Override
	public SmsEntity sendMessage(String template, String phone, String[] text, long sel) {
		
		// TODO Auto-generated method stub
		if(text == null ) text = new String[0];
		if(text.length==0){
			System.out.println(template + "--" + phone + "--" );
		}else{
			System.out.println(template + "--" + phone + "--" + text[0]);
		}
		

		String timestamp = DateUtils.getFormatDateStr(new Date(), DateUtils.DATA_FORMAT_YYYYMMDDHHMMSS);
		String sig = ACCOUNT_SID + AUTH_TOKEN + timestamp;
		System.out.println(sig);
		sig = MD5.sign(sig, "", "UTF-8");
        List<NameValuePair> nvps = new ArrayList<NameValuePair>();  
        nvps.add(new BasicNameValuePair("accountSid", ACCOUNT_SID));  
//      nvps.add(new BasicNameValuePair("appId", APP_ID));  
        nvps.add(new BasicNameValuePair("to", phone));  
        nvps.add(new BasicNameValuePair("timestamp", timestamp));  
        nvps.add(new BasicNameValuePair("sig", sig));  
        nvps.add(new BasicNameValuePair("respDataType", "JSON"));  
        nvps.add(new BasicNameValuePair("smsContent", text[0]));  

		System.out.println(timestamp + "--" + sig);
		String url = SMSTEMPLATE ;
		JSONObject ret = null;
		try {
			ret = SMSHttpHelper.httpPost(url,"form", nvps,null);
		} catch (OApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(ret);
		if (ret.containsKey("result")) {
			JSONObject result = ret.getJSONObject("result");
			SmsEntity se = new SmsEntity();
			se.setChannel(CHANNEL);
			se.setRespCode(result.getString("respCode"));
			se.setText(text[0]);
			if (result.containsKey("smsId"))
				se.setSmsId(result.getString("smsId"));
			if (result.containsKey("createDate"))
				se.setCreateDate(result.getString("createDate"));
			if (sel > 0)
				saveMsg(sel, se);
			return se;
		} else {
			return null;
		}
	}

	public static void main(String[] args) {
		BaseSmsMessageService x = new QingMaYunSmsMessageService();
//		SmsEntity e = x.sendAuthCode("13313169156", "341278", 0);
		SmsEntity e = x.sendMessage("22950013", "15210792449", new String[]{"【小微律政】尊敬的用户您好！您的公司注册流程已经全部完成，如果您接下来需要银行开户，您可以登陆小微律政官网继续办理后续服务。"}, 0);
		
		System.out.println(e);
/*		String[] text = new String[0];
		System.out.println(text.length);*/
	}

	public SmsEntity sendAuthCode(String phone, String code, long sel) {

		return sendMessage(AUTHCODE_TEMP, phone, new String[] {"【小微律政】您的验证码是" + code + ",有效期为15分钟。"}, sel);
	}
	@Override
	public void saveMsg(long se, SmsEntity see) {
		try {
			AuthMsgEntity ame = imss.getMsgEntityById(se);
			if (ame != null) {
				ame.setMsgid(see.getSmsId());
				ame.setMsgchannel(see.getChannel());
				if ("00000".equals(see.getRespCode())) {
					ame.setSendstate((short) 1);
				} else {
					ame.setSendstate((short) 0);
				}
				ame.setRespmessage(see.getOthMsg());
				ame.setRespcode(see.getRespCode());
				if (StringUtils.isNotBlank(see.getCreateDate())) {
					ame.setSendtimestamp(DateUtils.getDateFromStr(see.getCreateDate()));
				}
				imss.updateMsgEntity(ame);
//				ScheThreadPoolUtils.getExecutorPool().schedule(new QingMaYunSmsSaveMessageService(see.getSmsId()), 150, TimeUnit.SECONDS);
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
