package com.jx.service.messagecenter.contract;



import com.jx.spat.gaea.server.contract.annotation.OperationContract;
import com.jx.spat.gaea.server.contract.annotation.ServiceContract;

@ServiceContract
public interface IQyhService {

	@OperationContract
	public String getAccessToken(String corpID, String secret) throws Exception;

}
