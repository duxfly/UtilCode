package com.jx.service.messagecenter.components;

import java.util.List;

import com.jx.service.messagecenter.common.DBHelper;
import com.jx.service.messagecenter.contract.IActionService;
import com.jx.service.messagecenter.entity.OrderActionEntity;
import com.jx.spat.gaea.server.contract.annotation.ServiceBehavior;

@ServiceBehavior
public class ActionService implements IActionService {

	public OrderActionEntity getActionByid(long actionid) throws Exception {
		// TODO Auto-generated method stub
		return (OrderActionEntity) DBHelper.daoHelpers.sql.get(OrderActionEntity.class,actionid);
	}

	public List<OrderActionEntity> getActionsBypage(String condition,
			int pageindex, int pagesize, String orderby) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
